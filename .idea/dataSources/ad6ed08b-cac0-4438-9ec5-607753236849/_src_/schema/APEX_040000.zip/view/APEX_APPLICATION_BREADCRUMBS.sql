CREATE VIEW APEX_APPLICATION_BREADCRUMBS AS select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    m.NAME                           breadcrumb_name,
    --
    (select count(*) from wwv_flow_menu_options where menu_id = m.id) breadcrumb_entries,
    --
    m.LAST_UPDATED_BY                last_updated_by,
    m.LAST_UPDATED_ON                last_updated_on,
    m.MENU_COMMENT                   component_comment,
    m.id                             breadcrumb_id,
    --
    m.NAME
    component_signature
from wwv_flow_menus m,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = m.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_040000.APEX_APPLICATION_BREADCRUMBS IS 'Identifies the definition of a collection of Breadcrumb Entries which are used to identify a page Hierarchy'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_BREADCRUMBS.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_BREADCRUMBS.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_BREADCRUMBS.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_BREADCRUMBS.BREADCRUMB_NAME IS 'Identifies the Breadcrumb Name, a breadcrumb is a collection of Breadcrumb Entries used to show page context.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_BREADCRUMBS.BREADCRUMB_ENTRIES IS 'Count of Entries defined for this Breadcrumb'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_BREADCRUMBS.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_BREADCRUMBS.LAST_UPDATED_ON IS 'Date of last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_BREADCRUMBS.COMPONENT_COMMENT IS 'Developer Comment'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_BREADCRUMBS.BREADCRUMB_ID IS 'Primary key of this Breadcrumb'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_BREADCRUMBS.COMPONENT_SIGNATURE IS 'Identifies attributes defined at a given component level to facilitate application comparisons'
/
