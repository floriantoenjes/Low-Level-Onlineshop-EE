CREATE VIEW APEX_APPLICATION_PAGE_FLASH5 AS select
    w.short_name                     workspace,
    f.id                             application_id,
    f.name                           application_name,
    p.id                             page_id,
    p.name                           page_name,
    c.region_id                      region_id,
    (select plug_name
     from wwv_flow_page_plugs
     where id = c.region_id)         region_name,
    c.id                             chart_id,
    decode(c.chart_type,
    '2DColumn', '2D Column',
    '2DColumn_Line', '2D Column Line',
    '2DDoughnut', '2D Doughnut',
    '2DLine', '2D Line',
    '2DPie', '2D Pie',
    '3DColumn', '3D Column',
    '3DPie', '3D Pie',
    'Candlestick', 'Candlestick',
    'GaugeChart', 'Dial',
    'DIALSWEEP', 'Dial (Sweep)',
    'Horizontal2DColumn', 'Horizontal 2D Column',
    'Horizontal3DColumn', 'Horizontal 3D Column',
    'HorizontalRange3DColumn', 'Horizontal Range 3D Column',
    'HorizontalRange2DColumn', 'HorizontalRange 2D Column',
    'Inverse2DLine', 'Inverse 2D Line',
    'Range2DColumn', 'Range 2D Column',
    'Range3DColumn', 'Range 3D Column',
    'dot', 'Scatter',
    'ScatterMarker','Scatter',
    'Stacked2DColumn', 'Stacked 2D Column',
    '2DSTACKED_PCT', 'Stacked 2D Column (Percent)',
    'Stacked3DColumn', 'Stacked 3D Column',
    '3DSTACKED_PCT', 'Stacked 3D Column (Percent)',
    'StackedHorizontal2DColumn', 'Stacked Horizontal 2D Column',
    '2DHSTACKED_PCT', 'Stacked Horizontal 2D Column (Percent)',
    'StackedHorizontal3DColumn', 'Stacked Horizontal 3D Column',
    '3DHSTACKED_PCT', 'Stacked Horizontal 3D Column (Percent)',
    'ProjectGantt','Project Gantt',
    'ResourceGantt','Resource Gantt',
    'Map','Map',
    c.chart_type)                    chart_type,
    c.chart_title                    chart_title,
    c.chart_name                     chart_name,
    c.chart_width                    chart_width,
    c.chart_height                   chart_height,
    c.chart_animation                chart_animation,
    c.pie_attr                       pie_attr,
    c.display_attr                   display_attr,
    c.dial_tick_attr                 dial_tick_attr,
    c.gantt_attr                     gantt_attr,
    c.gantt_date_format              gantt_date_format,
    c.gantt_start_date               gantt_start_date,
    c.gantt_end_date                 gantt_end_date,
    c.map_attr                       map_attr,
    c.map_source                     map_source,
    c.margins                        margins,
    c.color_scheme                   color_scheme,
    c.custom_colors                  custom_colors,
    c.map_undef_color_scheme         map_undef_color_scheme,
    c.map_undef_custom_colors        map_undef_custom_colors,
    c.chart_bgtype                   chart_bgtype,
    c.chart_bgcolor                  chart_bgcolor,
    c.chart_bgcolor2                 chart_bgcolor2,
    c.chart_bgcorners                chart_bgcorners,
    c.chart_gradient_angle           chart_gradient_angle,
    c.grid_bgtype                    grid_bgtype,
    c.grid_bgcolor                   grid_bgcolor,
    c.grid_bgcolor2                  grid_bgcolor2,
    c.grid_gradient_angle            grid_gradient_angle,
    c.x_axis_title                   x_axis_title,
    c.x_axis_title_font              x_axis_title_font,
    c.x_axis_title_rotation          x_axis_title_rotation,
    c.x_axis_min                     x_axis_min,
    c.x_axis_max                     x_axis_max,
    c.x_axis_scroll_start            x_axis_scroll_start,
    c.x_axis_scroll_end              x_axis_scroll_end,
    c.x_axis_scroll_range            x_axis_scroll_range,
    c.x_axis_scroll_range_unit       x_axis_scroll_range_unit,
    c.x_axis_label_rotation          x_axis_label_rotation,
    c.x_axis_label_font              x_axis_label_font,
    c.x_axis_prefix                  x_axis_prefix,
    c.x_axis_postfix                 x_axis_postfix,
    c.x_axis_decimal_place           x_axis_decimal_place,
    c.x_axis_major_interval          x_axis_major_interval,
    c.x_axis_minor_interval          x_axis_minor_interval,
    c.y_axis_title                   y_axis_title,
    c.y_axis_title_font              y_axis_title_font,
    c.y_axis_title_rotation          y_axis_title_rotation,
    c.y_axis_min                     y_axis_min,
    c.y_axis_max                     y_axis_max,
    c.y_axis_scroll_start            y_axis_scroll_start,
    c.y_axis_scroll_end              y_axis_scroll_end,
    c.y_axis_scroll_range            y_axis_scroll_range,
    c.y_axis_scroll_range_unit       y_axis_scroll_range_unit,
    c.y_axis_label_rotation          y_axis_label_rotation,
    c.y_axis_label_font              y_axis_label_font,
    c.y_axis_prefix                  y_axis_prefix,
    c.y_axis_postfix                 y_axis_postfix,
    c.y_axis_decimal_place           y_axis_decimal_place,
    c.y_axis_major_interval          y_axis_major_interval,
    c.y_axis_minor_interval          y_axis_minor_interval,
    c.values_prefix                  values_prefix,
    c.values_postfix                 values_postfix,
    c.async_update                   async_update,
    c.async_time                     async_time,
    c.values_font                    values_font,
    c.values_rotation                values_rotation,
    c.tooltip_font                   tooltip_font,
    c.legend_title                   legend_title,
    c.legend_font                    legend_font,
    c.legend_title_font              legend_title_font,
    c.grid_labels_font               grid_labels_font,
    c.chart_title_font               chart_title_font,
    c.gauge_labels_font              gauge_labels_font,
    c.use_chart_xml                  use_chart_xml,
    c.chart_xml                      chart_xml,
    --
    c.updated_by                     last_updated_by,
    c.updated_on                     last_updated_on,
    --
    decode(c.chart_type,
    '2DColumn', '2D Column',
    '2DColumn_Line', '2D Column Line',
    '2DDoughnut', '2D Doughnut',
    '2DLine', '2D Line',
    '2DPie', '2D Pie',
    '3DColumn', '3D Column',
    '3DPie', '3D Pie',
    'Candlestick', 'Candlestick',
    'GaugeChart', 'Dial',
    'DIALSWEEP', 'Dial (Sweep)',
    'Horizontal2DColumn', 'Horizontal 2D Column',
    'Horizontal3DColumn', 'Horizontal 3D Column',
    'HorizontalRange3DColumn', 'Horizontal Range 3D Column',
    'HorizontalRange2DColumn', 'HorizontalRange 2D Column',
    'Inverse2DLine', 'Inverse 2D Line',
    'Range2DColumn', 'Range 2D Column',
    'Range3DColumn', 'Range 3D Column',
    'dot', 'Scatter',
    'ScatterMarker','Scatter',
    'Stacked2DColumn', 'Stacked 2D Column',
    '2DSTACKED_PCT', 'Stacked 2D Column (Percent)',
    'Stacked3DColumn', 'Stacked 3D Column',
    '3DSTACKED_PCT', 'Stacked 3D Column (Percent)',
    'StackedHorizontal2DColumn', 'Stacked Horizontal 2D Column',
    '2DHSTACKED_PCT', 'Stacked Horizontal 2D Column (Percent)',
    'StackedHorizontal3DColumn', 'Stacked Horizontal 3D Column',
    '3DHSTACKED_PCT', 'Stacked Horizontal 3D Column (Percent)',
    'ProjectGantt','Project Gantt',
    'ResourceGantt','Resource Gantt',
    'Map','Map',
    c.chart_type)
    ||' attr='||c.chart_width||c.chart_height||c.chart_animation||c.display_attr||c.dial_tick_attr||c.gantt_attr||c.map_attr||c.pie_attr||c.margins
    ||' color='||c.color_scheme||substr(c.custom_colors,1,20)||'.'||length(c.custom_colors)
               ||c.map_undef_color_scheme||substr(c.map_undef_custom_colors,1,20)||'.'||length(c.map_undef_custom_colors)
               ||c.chart_bgtype||substr(c.chart_bgcolor,1,20)||'.'||length(c.chart_bgcolor)||substr(c.chart_bgcolor2,1,20)||'.'||length(c.chart_bgcolor2)
               ||c.grid_bgtype||substr(c.grid_bgcolor,1,20)||'.'||length(c.grid_bgcolor)||substr(c.grid_bgcolor2,1,20)||'.'||length(c.grid_bgcolor2)
    ||' rotation='||c.chart_gradient_angle||':'||c.grid_gradient_angle||':'||c.x_axis_title_rotation||':'||c.x_axis_label_rotation||':'||c.y_axis_title_rotation||':'||c.y_axis_label_rotation||':'||c.values_rotation
    ||' title='||substr(c.chart_title,1,20)||'.'||length(c.chart_title)
    ||substr(c.x_axis_title,1,20)||'.'||length(c.x_axis_title)
    ||substr(c.y_axis_title,1,20)||'.'||length(c.y_axis_title)
    ||' name='||substr(c.chart_name,1,20)||'.'||length(c.chart_name)
    ||' axis='||c.x_axis_min||':'||c.x_axis_max||':'||substr(c.x_axis_prefix,1,20)||':'||substr(c.x_axis_postfix,1,20)||':'||c.x_axis_decimal_place
              ||':'||c.x_axis_major_interval||':'||c.x_axis_minor_interval||':'
              ||c.y_axis_min||':'||c.y_axis_max||':'||substr(c.y_axis_prefix,1,20)||':'||substr(c.y_axis_postfix,1,20)||':'||c.y_axis_decimal_place
              ||':'||c.y_axis_major_interval||':'||c.y_axis_minor_interval||':'||substr(c.values_prefix,1,20)||':'||substr(c.values_postfix,1,20)
    ||' font='||c.x_axis_label_font||c.y_axis_label_font||c.values_font||c.tooltip_font||c.legend_title_font||c.legend_font||c.grid_labels_font||c.gauge_labels_font||c.chart_title_font||c.x_axis_title_font||c.y_axis_title_font
    ||' xml='||decode(c.use_chart_xml,'Y',
                      dbms_lob.substr(c.chart_xml,30,1)||'.'||dbms_lob.getlength(c.chart_xml),
                      null)
    ||' refresh='||c.async_update||c.async_time
    component_signature
from wwv_flow_flash_charts_5 c,
     wwv_flow_steps p,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = p.security_group_id and
      f.id = p.flow_id and
      f.id = c.flow_id and
      p.id = c.page_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_040000.APEX_APPLICATION_PAGE_FLASH5 IS 'Identifies a Flash chart 5 chart associated with a Page and Region'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.PAGE_ID IS 'ID of the application page'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.PAGE_NAME IS 'Name of the application page'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.REGION_ID IS 'Identifies the Page Region foreign key to the apex_application_page_regions view'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.REGION_NAME IS 'Identifies the region name in which this Flash chart is displayed'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_ID IS 'Primary Key of the Flash chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_TYPE IS 'Chart type to indicate the style in which the Flash chart will render'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_TITLE IS 'A title to display at the top of the chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_NAME IS 'Identifes the name of the chart, to be used for dashboards'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_WIDTH IS 'Width of the chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_HEIGHT IS 'Height of the chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_ANIMATION IS 'An animation to control the initial appearance of the chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.PIE_ATTR IS 'Pie chart attribute'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.DISPLAY_ATTR IS 'Display attribute to show legend, grid, hints, labels and values'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.DIAL_TICK_ATTR IS 'Dial chart attribute to show ticks, show tick labels, and tick spacing'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.GANTT_ATTR IS 'Gantt chart attribute to show datagrid, show navigation bar, and the attributes of the actual,progress and baseline bars'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.GANTT_DATE_FORMAT IS 'The date format used for a Gantt chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.GANTT_START_DATE IS 'The start date for the Gantt chart timeline diplayed'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.GANTT_END_DATE IS 'The end date for the Gantt chart timeline displayed'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.MAP_ATTR IS 'Map chart attribute to show projection, label positioning, map center, legend item display angle'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.MARGINS IS 'Chart attribute for top, bottom, left, right margins'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.COLOR_SCHEME IS 'Pre-built color scheme for the chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CUSTOM_COLORS IS 'Set of custom colors defined by a user'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.MAP_UNDEF_COLOR_SCHEME IS 'Pre-built color scheme for the undefined map regions'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.MAP_UNDEF_CUSTOM_COLORS IS 'Set of custom colors defined by a user for the undefined map regions'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_BGTYPE IS 'Background type for the chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_BGCOLOR IS 'Background Color 1 for the chart.  If the background type is set to Gradient, the chart background fades from Background Color 1 to Background Color 2.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_BGCOLOR2 IS 'Background Color 2 for the chart.  If the background type is set to Gradient, the chart background fades from Background Color 1 to Background Color 2.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_GRADIENT_ANGLE IS 'The angle for the chart background gradient'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.GRID_BGTYPE IS 'Background type for the map grid.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.GRID_BGCOLOR IS 'Background Color 1 for the map grid.  If the background type is set to Gradient, the map grid background fades from Background Color 1 to Background Color 2.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.GRID_BGCOLOR2 IS 'Background Color 2 for the map grid.  If the background type is set to Gradient, the map grid background fades from Background Color 1 to Background Color 2.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.GRID_GRADIENT_ANGLE IS 'The angle for the map grid background gradient'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.X_AXIS_TITLE IS 'Title for the X Axis'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.X_AXIS_TITLE_FONT IS 'X Axis title font settings'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.X_AXIS_MIN IS 'The smallest data value to appear on the X Axis'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.X_AXIS_MAX IS 'The highest data value to appear on the X Axis'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.X_AXIS_PREFIX IS 'Text to display before X Axis values'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.X_AXIS_POSTFIX IS 'Text to display after X Axis values'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.X_AXIS_DECIMAL_PLACE IS 'Number of decimal places to use in X Axis values'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.X_AXIS_MAJOR_INTERVAL IS 'The major scale step, used for the X axis labels, major tickmarks and minor grid on your chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.X_AXIS_MINOR_INTERVAL IS 'The minor scale step, used for the X axis labels, minor tickmarks and minor grid on your chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.Y_AXIS_TITLE IS 'Title for the Y Axis'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.Y_AXIS_TITLE_FONT IS 'Y Axis title font settings'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.Y_AXIS_MIN IS 'The smallest data value to appear on the Y Axis'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.Y_AXIS_MAX IS 'The highest data value to appear on the Y Axis'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.Y_AXIS_PREFIX IS 'Text to display before Y Axis values'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.Y_AXIS_POSTFIX IS 'Text to display after Y Axis values'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.Y_AXIS_DECIMAL_PLACE IS 'Number of decimal places to use in Y Axis values'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.Y_AXIS_MAJOR_INTERVAL IS 'The major scale step, used for the Y axis labels, major tickmarks and minor grid on your chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.Y_AXIS_MINOR_INTERVAL IS 'The minor scale step, used for the Y axis labels, minor tickmarks and minor grid on your chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.VALUES_PREFIX IS 'Text to display before values on a Pie chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.VALUES_POSTFIX IS 'Text to display after values on a Pie chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.ASYNC_UPDATE IS 'A flag to enable an asynchronous graph update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.ASYNC_TIME IS 'The interval in seconds between chart updates'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.VALUES_FONT IS 'Chart value text font settings'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.VALUES_ROTATION IS 'The amount of rotation for the values'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.TOOLTIP_FONT IS 'Chart hint text font settings'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.LEGEND_FONT IS 'Chart legend text font settings'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.LEGEND_TITLE_FONT IS 'Chart legend title text font settings'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.GRID_LABELS_FONT IS 'Chart grid label font settings'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_TITLE_FONT IS 'Chart title font settings'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.USE_CHART_XML IS 'A flag to override generated XML and use a custom chart XML'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.CHART_XML IS 'User defined custom Chart XML for the Flash chart'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.LAST_UPDATED_ON IS 'Date of last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_PAGE_FLASH5.COMPONENT_SIGNATURE IS 'Identifies attributes defined at a given component level to facilitate application comparisons'
/
