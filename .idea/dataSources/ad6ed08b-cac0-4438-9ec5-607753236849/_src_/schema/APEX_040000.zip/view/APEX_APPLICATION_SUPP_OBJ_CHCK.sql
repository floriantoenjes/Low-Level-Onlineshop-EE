CREATE VIEW APEX_APPLICATION_SUPP_OBJ_CHCK AS select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    c.ID                             check_id,
    c.NAME                           check_name,
    c.SEQUENCE                       check_sequence,
    --
    c.CHECK_TYPE                     check_type,
    c.CHECK_CONDITION                check_expression1,
    c.CHECK_CONDITION2               check_expression2,
    --
    --c.SUCCESS_MESSAGE                ,
    c.FAILURE_MESSAGE                error_message,
    --
    c.CONDITION_TYPE                 condition_type,
    c.CONDITION                      condition_expression1,
    c.CONDITION2                     condition_expression2,
    --
    c.LAST_UPDATED_BY                last_updated_by,
    c.LAST_UPDATED_ON                last_updated_on,
    c.CREATED_BY                     created_by,
    c.CREATED_ON                     created_on
from
     wwv_flow_install_checks c,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.id = c.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK IS 'Identifies the Supporting Object pre-installation checks to ensure the database is compatible with the objects to be installed'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_ID IS 'Specifies the ID for this validation.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_NAME IS 'Specifies the name for this validation.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_SEQUENCE IS 'Specifies the sequence for this validation. The sequence number determines the order of evaluation.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_TYPE IS 'Specifies the condition type that must be met during installation before installation scripts are run.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_EXPRESSION1 IS 'Use this attribute to conditionally control whether installation can continue. Values correspond to the specific condition type selected.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_EXPRESSION2 IS 'Use this attribute to conditionally control whether installation can continue. Values correspond to the specific condition type selected.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.ERROR_MESSAGE IS 'Enter a message to be displayed when the conditions of this validation are not met.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CONDITION_TYPE IS 'Specifies a condition type from the list that conditionally controls whether this validation is performed.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CONDITION_EXPRESSION1 IS 'Specifies an expression based on the specific condition type selected.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CONDITION_EXPRESSION2 IS 'Specifies an expression based on the specific condition type selected.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.LAST_UPDATED_ON IS 'Date of last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CREATED_BY IS 'Identifies the User Name of the APEX developer who created this check condition'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_SUPP_OBJ_CHCK.CREATED_ON IS 'Identifies the date that this component was created'
/
