CREATE VIEW APEX_APPLICATION_TEMP_LIST AS select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.LIST_TEMPLATE_NAME             template_name,
    t.LIST_TEMPLATE_CURRENT,
    t.LIST_TEMPLATE_NONCURRENT,
    t.LIST_TEMPLATE_BEFORE_ROWS,
    t.LIST_TEMPLATE_AFTER_ROWS,
    t.BETWEEN_ITEMS,
    t.BEFORE_SUB_LIST,
    t.AFTER_SUB_LIST,
    t.BETWEEN_SUB_LIST_ITEMS,
    t.SUB_LIST_ITEM_CURRENT,
    t.SUB_LIST_ITEM_NONCURRENT,
    t.ITEM_TEMPLATE_CURR_W_CHILD,
    t.ITEM_TEMPLATE_NONCURR_W_CHILD,
    t.SUB_TEMPLATE_CURR_W_CHILD,
    t.SUB_TEMPLATE_NONCURR_W_CHILD,
    --
    t.FIRST_LIST_TEMPLATE_NONCURRENT,
    t.FIRST_LIST_TEMPLATE_CURRENT,
    t.F_ITEM_TEMPLATE_CURR_W_CHILD,
    t.FITEM_TEMPLATE_NONCURR_W_CHILD,
    --
    decode(t.REFERENCE_ID,
    null,'No','Yes')                 is_subscribed,
    (select flow_id||'. '||name
     from WWV_FLOW_LIST_TEMPLATES
     where id = t.REFERENCE_ID)      subscribed_from,
    --
    t.LAST_UPDATED_BY                ,
    t.LAST_UPDATED_ON                ,
    t.THEME_ID                       theme_number,
    decode(t.THEME_CLASS_ID,
       '1','Vertical Unordered List with Bullets',
       '2','Vertical Ordered List',
       '3','Horizontal Links List',
       '4','Horizontal Images with Label List',
       '5','Vertical Images List',
       '6','Button List',
       '7','Tabbed Navigation List',
       '9','Custom 1',
       '10','Custom 2',
       '11','Custom 3',
       '12','Custom 4',
       '13','Custom 5',
       '14','Custom 6',
       '15','Custom 7',
       '16','Custom 8',
       '17','Wizard Progress List',
       '18','Vertical Unordered List without Bullets',
       '19','Vertical Sidebar List',
       '20','Pull Down Menu',
       '21','Pull Down Menu with Image',
       '22','Hierarchical Expanding',
       '23','Hierarchical Expanded',
       t.THEME_CLASS_ID)             theme_class,
    t.TRANSLATE_THIS_TEMPLATE,
    t.LIST_TEMPLATE_COMMENT          component_comment,
    t.id                             list_template_id,
    --
    t.LIST_TEMPLATE_NAME
    ||' t='||t.THEME_ID
    ||' c='||t.THEME_CLASS_ID
    ||' 1='||dbms_lob.substr(t.LIST_TEMPLATE_CURRENT,40,1)||'.'||dbms_lob.getlength(t.LIST_TEMPLATE_CURRENT)
    ||' 2='||dbms_lob.substr(t.LIST_TEMPLATE_NONCURRENT,40,1)||'.'||dbms_lob.getlength(t.LIST_TEMPLATE_NONCURRENT)
    ||' 3='||dbms_lob.substr(t.SUB_LIST_ITEM_CURRENT,40,1)||'.'||dbms_lob.getlength(t.SUB_LIST_ITEM_CURRENT)
    ||' 4='||dbms_lob.substr(t.SUB_LIST_ITEM_NONCURRENT,40,1)||'.'||dbms_lob.getlength(t.SUB_LIST_ITEM_NONCURRENT)
    ||' 5='||dbms_lob.substr(t.ITEM_TEMPLATE_CURR_W_CHILD,40,1)||'.'||dbms_lob.getlength(t.ITEM_TEMPLATE_CURR_W_CHILD)
    ||' 6='||dbms_lob.substr(t.ITEM_TEMPLATE_NONCURR_W_CHILD,40,1)||'.'||dbms_lob.getlength(t.ITEM_TEMPLATE_NONCURR_W_CHILD)
    ||' 7='||dbms_lob.substr(t.SUB_TEMPLATE_CURR_W_CHILD,40,1)||'.'||dbms_lob.getlength(t.SUB_TEMPLATE_CURR_W_CHILD)
    ||' 8='||dbms_lob.substr(t.SUB_TEMPLATE_NONCURR_W_CHILD,40,1)||'.'||dbms_lob.getlength(t.SUB_TEMPLATE_NONCURR_W_CHILD)
    ||' t='||t.TRANSLATE_THIS_TEMPLATE
    ||' r='||decode(t.REFERENCE_ID,null,'N','Y')
    ||' b='||substr(t.LIST_TEMPLATE_BEFORE_ROWS,1,20)||length(t.LIST_TEMPLATE_BEFORE_ROWS)
    ||' a='||substr(t.LIST_TEMPLATE_AFTER_ROWS,1,20)||length(t.LIST_TEMPLATE_AFTER_ROWS)
    ||' b='||substr(t.BETWEEN_ITEMS,1,20)||length(t.BETWEEN_ITEMS)
    ||' b='||substr(t.BEFORE_SUB_LIST,1,20)||length(t.BEFORE_SUB_LIST)
    ||' a='||substr(t.AFTER_SUB_LIST,1,20)||length(t.AFTER_SUB_LIST)
    ||' b='||substr(t.BETWEEN_SUB_LIST_ITEMS,1,20)||length(t.BETWEEN_SUB_LIST_ITEMS)
    component_signature
from WWV_FLOW_LIST_TEMPLATES t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_040000.APEX_APPLICATION_TEMP_LIST IS 'Identifies HTML template markup used to render a List with List Elements'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.TEMPLATE_NAME IS 'Identifies the List template name'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.LIST_TEMPLATE_CURRENT IS 'HTML or text to be substituted for the selected (or current) list entry'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.LIST_TEMPLATE_NONCURRENT IS 'HTML or text to be substituted for the non selected (or non-current) list entry'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.LIST_TEMPLATE_BEFORE_ROWS IS 'HTML that displays before any list elements. You can use this attribute to open an HTML table or HTML table row'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.LIST_TEMPLATE_AFTER_ROWS IS 'HTML that displays after list elements. You can use this attribute to close an HTML table or HTML table row'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.BETWEEN_ITEMS IS 'HTML that displays between list elements'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.BEFORE_SUB_LIST IS 'HTML that displays before any sub list elements. '
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.AFTER_SUB_LIST IS 'HTML that displays after any sub list elements.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.BETWEEN_SUB_LIST_ITEMS IS 'HTML that displays between sub list elements'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.SUB_LIST_ITEM_CURRENT IS 'HTML or text to be substituted for the selected (or current) sub list entry'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.SUB_LIST_ITEM_NONCURRENT IS 'HTML or text to be substituted for the unselected (or noncurrent) sub list entry'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.ITEM_TEMPLATE_CURR_W_CHILD IS 'HTML or text to be substituted for the selected (or current) sub list template used when an item has sub list entries'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.ITEM_TEMPLATE_NONCURR_W_CHILD IS 'HTML or text to be substituted for the unselected (or noncurrent) list template used when item has sub list items'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.SUB_TEMPLATE_CURR_W_CHILD IS 'HTML or text to be substituted for the selected (or current) sub list template used when an item has sub list entries'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.SUB_TEMPLATE_NONCURR_W_CHILD IS 'HTML or text to be substituted for the unselected (or noncurrent) list template used when item has sub list items'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.FIRST_LIST_TEMPLATE_NONCURRENT IS 'First list template for non current entry template.  Defaults to list template non current.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.FIRST_LIST_TEMPLATE_CURRENT IS 'First list template for current entry template.  Defaults to list template current.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.F_ITEM_TEMPLATE_CURR_W_CHILD IS 'First item template for current entry with child'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.FITEM_TEMPLATE_NONCURR_W_CHILD IS 'First item template for non current entry with child'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.IS_SUBSCRIBED IS 'Identifies if this List Template is subscribed from another List Template'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.SUBSCRIBED_FROM IS 'Identifies the master component from which this component is subscribed'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.LAST_UPDATED_ON IS 'Date of last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.THEME_NUMBER IS 'Identifies the numeric identifier of this theme to which this template is associated'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.THEME_CLASS IS 'Identifies a specific usage for this template'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.TRANSLATE_THIS_TEMPLATE IS 'Identifies if this template should be translated'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.COMPONENT_COMMENT IS 'Developer comment'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.LIST_TEMPLATE_ID IS 'Primary Key of this template'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TEMP_LIST.COMPONENT_SIGNATURE IS 'Identifies attributes defined at a given component level to facilitate application comparisons'
/
