CREATE VIEW APEX_APPLICATION_TRANSLATIONS AS select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.NAME                           translatable_message,
    t.MESSAGE_LANGUAGE               language_code,
    --
    t.MESSAGE_TEXT                   message_text,
    t.LAST_UPDATED_BY                last_updated_by,
    t.LAST_UPDATED_ON                last_updated_on,
    t.MESSAGE_COMMENT                developer_comment,
    t.id                             translation_entry_id
from WWV_FLOW_MESSAGES$ t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      /* keep this language map not exists */
      not exists (
        select 1 from wwv_flow_language_map
        where translation_flow_id = f.id) and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_040000.APEX_APPLICATION_TRANSLATIONS IS 'Identifies message primary language text and translated text'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TRANSLATIONS.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TRANSLATIONS.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TRANSLATIONS.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TRANSLATIONS.TRANSLATABLE_MESSAGE IS 'Identifies the Message Name'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TRANSLATIONS.LANGUAGE_CODE IS 'Identifies the Language Code'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TRANSLATIONS.MESSAGE_TEXT IS 'Identifies the message text in the Language Code language'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TRANSLATIONS.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TRANSLATIONS.LAST_UPDATED_ON IS 'Date of last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TRANSLATIONS.DEVELOPER_COMMENT IS 'Developer Comment'
/
COMMENT ON COLUMN APEX_040000.APEX_APPLICATION_TRANSLATIONS.TRANSLATION_ENTRY_ID IS 'Primary Key of this Translation Entry'
/
