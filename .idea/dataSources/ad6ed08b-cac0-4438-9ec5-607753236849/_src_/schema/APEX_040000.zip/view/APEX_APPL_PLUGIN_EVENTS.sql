CREATE VIEW APEX_APPL_PLUGIN_EVENTS AS select e.id                 as plugin_event_id,
       f.workspace,
       f.application_id,
       f.application_name,
       e.plugin_id,
       p.name               as plugin_name,
       e.name,
       e.display_name,
       e.created_by,
       e.created_on,
       e.last_updated_by,
       e.last_updated_on
  from wwv_flow_authorized f,
       wwv_flow_plugins p,
       wwv_flow_plugin_events e
 where p.flow_id   = f.application_id
   and e.plugin_id = p.id
/
COMMENT ON VIEW APEX_040000.APEX_APPL_PLUGIN_EVENTS IS 'Stores which events can be triggered by this plug-in. This events are used for binding dynamic actions.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.PLUGIN_EVENT_ID IS 'Identifies the primary key of this component'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.PLUGIN_ID IS 'Id of the plug-in this plug-in event is part of'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.PLUGIN_NAME IS 'Name of the plug-in this plug-in event is part of'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.NAME IS 'Internal name of the event which is used to reference it from apex_application_page_da and to bind the Javascript event.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.DISPLAY_NAME IS 'Contains the name of the event which is displayed on the UI.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.CREATED_BY IS 'APEX developer who created the plug-in event'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.CREATED_ON IS 'Date of creation'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_EVENTS.LAST_UPDATED_ON IS 'Date of last update'
/
