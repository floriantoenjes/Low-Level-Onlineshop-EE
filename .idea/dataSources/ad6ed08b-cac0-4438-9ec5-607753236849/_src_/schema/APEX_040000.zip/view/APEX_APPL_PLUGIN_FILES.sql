CREATE VIEW APEX_APPL_PLUGIN_FILES AS select a.id                 as plugin_file_id,
       f.workspace,
       f.application_id,
       f.application_name,
       a.plugin_id,
       p.name               as plugin_name,
       a.file_name,
       a.mime_type,
       a.file_charset,
       a.file_content,
       a.created_by,
       a.created_on,
       a.last_updated_by,
       a.last_updated_on
  from wwv_flow_authorized f,
       wwv_flow_plugins p,
       wwv_flow_plugin_files a
 where p.flow_id   = f.application_id
   and a.plugin_id = p.id
/
COMMENT ON VIEW APEX_040000.APEX_APPL_PLUGIN_FILES IS 'Stores the files like CSS, images, javascript files, ... of a plug-in.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.PLUGIN_FILE_ID IS 'Identifies the primary key of this component'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.PLUGIN_ID IS 'Id of the plug-in this plug-in file is part of'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.PLUGIN_NAME IS 'Name of the plug-in this plug-in file is part of'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.FILE_NAME IS 'Name of the file.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.MIME_TYPE IS 'Mime type of the file.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.FILE_CHARSET IS 'IANA charset used for text files.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.FILE_CONTENT IS 'Blob content of the file.'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.CREATED_BY IS 'APEX developer who created the plug-in file'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.CREATED_ON IS 'Date of creation'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.LAST_UPDATED_BY IS 'APEX developer who made last update'
/
COMMENT ON COLUMN APEX_040000.APEX_APPL_PLUGIN_FILES.LAST_UPDATED_ON IS 'Date of last update'
/
