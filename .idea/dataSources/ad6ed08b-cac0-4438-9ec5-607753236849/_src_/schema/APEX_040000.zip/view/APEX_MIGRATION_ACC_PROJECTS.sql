CREATE VIEW APEX_MIGRATION_ACC_PROJECTS AS select
        a.project_id                                    project_id,
     --
        d.migration_name                                project_name,
     --
        d.description                                   description,
     --
        d.migration_type                                migration_type,
     --
        d.created_by                                    project_owner,
     --
        a.dbpathname                                    accdb_pathname,
     --
       (select count(*) from wwv_mig_acc_tables
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              tables,
     --
       (select count(*) from wwv_mig_acc_queries
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              queries,
     --
       (select count(*) from wwv_mig_acc_forms
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              forms,
     --
       (select count(*) from wwv_mig_acc_reports
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              reports,
     --
       (select count(*) from wwv_mig_acc_pages
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              pages,
     --
       (select count(*) from wwv_mig_acc_modules
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              modules,
     --
       (select count(*) from wwv_mig_acc_relations
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              relations,
     --
        a.jetversion                                    jetversion,
     --
        a.accessversion                                 accessversion,
     --
        a.dbname                                        dbname,
     --
        a.dbid                                          dbid,
     --
        a.dbsize                                        dbsize,
     --
        a.isappdb                                       isappdb,
     --
        a.isattacheddb                                  isattacheddb,
     --
        a.startupform                                   startupform,
     --
        a.linkdbid                                      linkdbid,
     --
        a.created_by                                    created_by,
     --
        d.last_updated_on                               last_modified_on,
     --
        d.last_updated_by                               last_modified_by,
     --
        s.schema                                        schema,
     --
        w.short_name                                    workspace,
     --
        w.provisioning_company_id                       workspace_id
from
        wwv_mig_access a,
     --
        wwv_flow_company_schemas s,
     --
        wwv_mig_projects d,
     --
        wwv_flow_companies w,
     --
        (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) g
where
        (s.schema = user or user in ('SYS','SYSTEM','APEX_040000') or g.sgid = w.PROVISIONING_COMPANY_ID)
and     w.PROVISIONING_COMPANY_ID != 0
and     a.database_schema = s.schema
and     a.project_id = d.id
and     a.security_group_id = d.security_group_id
and     w.provisioning_company_id = a.security_group_id
and     w.provisioning_company_id = s.security_group_id
order by w.PROVISIONING_COMPANY_ID, a.project_id
/
COMMENT ON VIEW APEX_040000.APEX_MIGRATION_ACC_PROJECTS IS 'Available Application Express (Apex) Application Migrations MS Access Migration Projects'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.PROJECT_ID IS 'Primary key that identifies the migration project'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.PROJECT_NAME IS 'Identifies name of the migration project'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.DESCRIPTION IS 'A brief description of the migration project'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.MIGRATION_TYPE IS 'Identifies the type of Migration Project'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.PROJECT_OWNER IS 'Identifies the Apex User Name who created and owns the Migration Project'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.ACCDB_PATHNAME IS 'Identifies full path name and location of the Microsoft Access database the migration project is based on'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.TABLES IS 'Number of tables in the original MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.QUERIES IS 'Number of queries in the original MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.FORMS IS 'Number of forms in the original MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.REPORTS IS 'Number of reports in the original MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.MODULES IS 'Number of modules in the original MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.RELATIONS IS 'Number of relationships in the original MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.JETVERSION IS 'Version of Microsoft Jet for MS Access associated with captured Microsoft Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.ACCESSVERSION IS 'Version of Microsoft Access database captured, which the migration project is based on'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.DBNAME IS 'Identifies the name of the original MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.DBID IS 'Identifies the unique number of the original MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.DBSIZE IS 'Identifies the size of the original MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.ISAPPDB IS 'Identifies whether the MS Access database is a single or parent database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.ISATTACHEDDB IS 'Identifies whether the MS Access database is attached to a parent database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.STARTUPFORM IS 'Identifies the name of the startup form in the MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.LINKDBID IS 'Identifies the unique number of the MS Access database that this parent database is linked to'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.CREATED_BY IS 'Identifies the name of the user who created the original MS Access database'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.LAST_MODIFIED_ON IS 'Date of most recent changes to the Migration Project'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.LAST_MODIFIED_BY IS 'Identifies the APEX User Name who last modified the Migration Project'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.SCHEMA IS 'Identifies the name of database schema associated with the Migration Project'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_040000.APEX_MIGRATION_ACC_PROJECTS.WORKSPACE_ID IS 'Primary key that identifies the workspace'
/
