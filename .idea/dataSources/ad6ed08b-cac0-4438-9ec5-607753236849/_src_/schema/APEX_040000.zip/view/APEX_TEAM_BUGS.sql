CREATE VIEW APEX_TEAM_BUGS AS select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    --
    b.ID                          bug_id,
    b.BUG_ID                      friendly_bug_number,
    b.BUG_TITLE                   bug_title,
    b.ASSIGNED_TO                 assigned_to,
    b.BUG_SEVERITY                bug_severity,
    b.BUG_STATUS                  bug_status,
    b.PRIORITY                    priority,
    b.FIX_BY_RELEASE              fix_by_release,
    --
    b.ESTIMATED_FIX_DATE,
    b.ACTUAL_FIX_DATE,
    --
    b.BUG_DESCRIPTION,
    b.REPORTED_PLATFORM,
    b.REPORTED_BROWSER,
    b.REPORTED_OPERATING_SYSTEM,
    b.FEATURE_ID                  related_feature_id,
    b.TARGET_MILESTONE_ID         target_milestone_id,
    b.TASK_ID                     related_todo_id,
    b.DUPLICATE_OF_BUG,
    b.TAGS,
    --
    b.CUSTOMER_NAME               customer_name,
    b.CUSTOMER_ISSUE              customer_issue,
    --
    b.COMPONENT                   product_component,
    b.PRODUCT                     product_name,
    b.PRODUCT_VERSION             product_version,
    b.IMPACT                      impact_of_fix,
    b.APPLICATION_ID              application_id,
    b.PAGE_ID                     page_id,
    --
    b.CREATED_BY,
    b.CREATED_ON,
    b.UPDATED_BY,
    b.UPDATED_ON
from
    wwv_flow_bugs b,
    wwv_flow_companies w
where
    b.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/
COMMENT ON VIEW APEX_040000.APEX_TEAM_BUGS IS 'Identifies bugs, also known as software defects.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.WORKSPACE_ID IS 'Primary key that identifies the workspace.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.WORKSPACE_NAME IS 'Name of the workspace.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.BUG_ID IS 'Primary key of the bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.BUG_TITLE IS 'Primary name for this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.ASSIGNED_TO IS 'Name of developer assigned to fix this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.BUG_SEVERITY IS 'The severity of this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.BUG_STATUS IS 'The status of this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.PRIORITY IS 'The priority assigned to this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.FIX_BY_RELEASE IS 'The release when this bug should be fixed.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.ESTIMATED_FIX_DATE IS 'The estimated fix date of the bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.ACTUAL_FIX_DATE IS 'The date the bug was actually fixed.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.BUG_DESCRIPTION IS 'Detailed description of the bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.REPORTED_PLATFORM IS 'Platform the bug was reported on.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.REPORTED_BROWSER IS 'Browser being used when bug was noticed.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.REPORTED_OPERATING_SYSTEM IS 'Operating system the buy was reported on.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.RELATED_FEATURE_ID IS 'Unique identifier of the related feature.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.TARGET_MILESTONE_ID IS 'Unique identifier of the milestone for when this bug is targeted to be completed.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.RELATED_TODO_ID IS 'Unique identifier of related To Do.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.DUPLICATE_OF_BUG IS 'If this bug is a duplicate of an existing bug, the unique identifier of the other bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.TAGS IS 'Tags associated with this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.CUSTOMER_NAME IS 'Name of customer reporting this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.CUSTOMER_ISSUE IS 'A description of the bug as described by the customer.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.PRODUCT_COMPONENT IS 'Product component (if available) associated with this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.PRODUCT_NAME IS 'Product associated with this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.PRODUCT_VERSION IS 'Specifid version of product associated with this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.IMPACT_OF_FIX IS 'The modules, components or patches that this bug fix will impact.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.APPLICATION_ID IS 'Associated application.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.PAGE_ID IS 'Relevant page within associated application.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.CREATED_BY IS 'Developer who created this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.CREATED_ON IS 'Date on which this bug was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.UPDATED_BY IS 'Developer who last updated this bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_BUGS.UPDATED_ON IS 'Date on which this bug was last updated.'
/
