CREATE VIEW APEX_TEAM_FEEDBACK AS select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    --
    f.ID                        feedback_id,
    f.deployment_system||
    f.feedback_id               feedback_number,
    f.FEEDBACK_COMMENT          feedback,
    f.FEEDBACK_TYPE             feedback_type,
    f.FEEDBACK_STATUS           feedback_status,
    f.deployment_system         deployment_system,
    --
    f.APPLICATION_ID            application_id,
    f.APPLICATION_NAME          application_name,
    f.APPLICATION_VERSION       application_version,
    f.PAGE_ID                   page_id,
    f.PAGE_NAME                 page_name,
    f.PAGE_LAST_UPDATED_BY      page_last_updated_by,
    f.PAGE_LAST_UPDATED_ON      page_last_updated,
    f.SESSION_ID                logging_session_id,
    f.APEX_USER                 logging_apex_user,
    f.user_email                logging_user_email,
    --
    f.SESSION_STATE,
    f.PARSING_SCHEMA,
    f.screen_width,
    f.screen_height,
    f.HTTP_USER_AGENT,
    f.REMOTE_ADDR,
    f.REMOTE_USER,
    f.HTTP_HOST,
    f.SERVER_NAME,
    f.SERVER_PORT,
    --
    f.LOGGED_BY_WORKSPACE_NAME   logging_workspace_name,
    f.LOGGING_SECURITY_GROUP_ID  logging_workspace_id,
    f.LOGGING_EMAIL,
    --
    f.SESSION_INFO               session_info,
    f.tags                       tags,
    f.DEVELOPER_COMMENT          developer_comment,
    f.public_response            public_response,
    f.BUG_ID                     logged_as_bug_id,
    f.FEATURE_ID                 logged_as_feature_id,
    f.TASK_ID                    logged_as_todo_id,
    --
    f.LABEL_01,
    f.LABEL_02,
    f.LABEL_03,
    f.LABEL_04,
    f.LABEL_05,
    f.LABEL_06,
    f.LABEL_07,
    f.LABEL_08,
    --
    f.ATTRIBUTE_01,
    f.ATTRIBUTE_02,
    f.ATTRIBUTE_03,
    f.ATTRIBUTE_04,
    f.ATTRIBUTE_05,
    f.ATTRIBUTE_06,
    f.ATTRIBUTE_07,
    f.ATTRIBUTE_08,
    --
    f.CREATED_BY,
    f.CREATED_ON,
    f.UPDATED_BY,
    f.UPDATED_ON
from
    wwv_flow_feedback f,
    wwv_flow_companies w
where
    f.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/
COMMENT ON VIEW APEX_040000.APEX_TEAM_FEEDBACK IS 'Identifies user feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.WORKSPACE_ID IS 'Primary key that identifies the workspace.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.WORKSPACE_NAME IS 'Name of the current workspace.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.FEEDBACK_ID IS 'Primary key of the feedback entry.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.FEEDBACK_NUMBER IS 'External identifier for the feedback entry.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.FEEDBACK IS 'Comment provided by application user'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.FEEDBACK_TYPE IS 'The type of feedback (identified by the user).'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.FEEDBACK_STATUS IS 'The status of the Feedback as assigned by the reviewing developers.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.DEPLOYMENT_SYSTEM IS 'Identifies the system where the feedback entry has been created.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.APPLICATION_ID IS 'Unique identifier of the application the feedback was provided on.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.APPLICATION_NAME IS 'Name of the application the Feedback was provided on.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.APPLICATION_VERSION IS 'Version of the application the feedback was provided on.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.PAGE_ID IS 'Unique identifier of the page within the application that the feedback was provided on.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.PAGE_NAME IS 'Name of the page within the application that the feedback was provided on.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.PAGE_LAST_UPDATED_BY IS 'The developer that last updated the referenced page.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.PAGE_LAST_UPDATED IS 'The date on which the referenced page was last updated.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LOGGING_SESSION_ID IS 'The Session ID when the feedback was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LOGGING_APEX_USER IS 'Application Express user providing the feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LOGGING_USER_EMAIL IS 'Email address of Application Express user providing the feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.SESSION_STATE IS 'The session state when the feedback was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.PARSING_SCHEMA IS 'The parsing schema of the application when the feedback was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.SCREEN_WIDTH IS 'Screen width when feedback was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.SCREEN_HEIGHT IS 'Screen height when feedback was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.HTTP_USER_AGENT IS 'HTTP User Agent where the feedback was provided (can be different that where the feedback is being reviewed).'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.REMOTE_ADDR IS 'Remote Address where the feedback was provided (can be different that where the feedback is being reviewed).'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.REMOTE_USER IS 'Remote User where the feedback was provided.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.HTTP_HOST IS 'HTTP Host where the feedback was provided (can be different that where the feedback is being reviewed).'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.SERVER_NAME IS 'The name of the server where the feedback was provided (can be different that where the feedback is being reviewed).'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.SERVER_PORT IS 'Server Port where the Feedback was provided (can be different that where the Feedback is being reviewed).'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LOGGING_WORKSPACE_NAME IS 'Name of workspace where feedbacl was collected.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LOGGING_WORKSPACE_ID IS 'Unique identifier of workspace where feedback was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LOGGING_EMAIL IS 'Email of user from workspace where feedback was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.SESSION_INFO IS 'Session Header from session when feedback was collected.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.TAGS IS 'Tags associated with the feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.DEVELOPER_COMMENT IS 'Comments or notes for internal use, not typically viewable by end-users.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.PUBLIC_RESPONSE IS 'The public response to the feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LOGGED_AS_BUG_ID IS 'If feedback resulted in a bug, the unique identifier of the resulting bug.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LOGGED_AS_FEATURE_ID IS 'If feedback resulted in a feature, the unique identifier of the resulting feature.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LOGGED_AS_TODO_ID IS 'If feedback resulted in a to do, the unique identifier of the resulting to do.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LABEL_01 IS 'Identifies the label for corresponding attribute.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LABEL_02 IS 'Identifies the label for corresponding attribute.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LABEL_03 IS 'Identifies the label for corresponding attribute.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LABEL_04 IS 'Identifies the label for corresponding attribute.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LABEL_05 IS 'Identifies the label for corresponding attribute.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LABEL_06 IS 'Identifies the label for corresponding attribute.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LABEL_07 IS 'Identifies the label for corresponding attribute.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.LABEL_08 IS 'Identifies the label for corresponding attribute.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.ATTRIBUTE_01 IS 'Custom attribute for collecting feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.ATTRIBUTE_02 IS 'Custom attribute for collecting feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.ATTRIBUTE_03 IS 'Custom attribute for collecting feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.ATTRIBUTE_04 IS 'Custom attribute for collecting feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.ATTRIBUTE_05 IS 'Custom attribute for collecting feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.ATTRIBUTE_06 IS 'Custom attribute for collecting feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.ATTRIBUTE_07 IS 'Custom attribute for collecting feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.ATTRIBUTE_08 IS 'Custom attribute for collecting feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.CREATED_BY IS 'User that created this feedback.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.CREATED_ON IS 'Date this feedback was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.UPDATED_BY IS 'Developer who made last update.'
/
COMMENT ON COLUMN APEX_040000.APEX_TEAM_FEEDBACK.UPDATED_ON IS 'Date of last update.'
/
