CREATE VIEW APEX_UI_DEFAULTS_GROUPS AS select t.schema,
       t.table_name,
       g.group_name,
       g.description,
       g.display_sequence,
       g.created_by,
       g.created_on,
       g.last_updated_by,
       g.last_updated_on
  from wwv_flow_hnt_groups g,
       wwv_flow_hnt_table_info t
 where t.schema   = user
   and g.table_id = t.table_id
/
COMMENT ON VIEW APEX_040000.APEX_UI_DEFAULTS_GROUPS IS 'The User Interface Defaults for the groups within the tables in this schema.  Used by the wizards when generating applications.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_GROUPS.SCHEMA IS 'Schema owning table.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_GROUPS.TABLE_NAME IS 'Name of table in the schema.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_GROUPS.GROUP_NAME IS 'When creating a form based upon this table, this will be used to group columns together into regions and this will be used as the region title.  When creating an interactive report against this table, this will be used to group the columns together and this will be used as the group name.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_GROUPS.DESCRIPTION IS 'Description of the group.  Not used during generation.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_GROUPS.DISPLAY_SEQUENCE IS 'Used to provide sequence of regions within a form and groups within an interactive report.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_GROUPS.CREATED_BY IS 'Auditing; user that created the record.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_GROUPS.CREATED_ON IS 'Auditing; date the record was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_GROUPS.LAST_UPDATED_BY IS 'Auditing; user that last modified the record.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_GROUPS.LAST_UPDATED_ON IS 'Auditing; date the record was last modified.'
/
