CREATE VIEW APEX_UI_DEFAULTS_TABLES AS select schema,
       table_name,
       form_region_title,
       report_region_title,
       created_by,
       created_on,
       last_updated_by,
       last_updated_on
  from wwv_flow_hnt_table_info
 where schema = user
/
COMMENT ON VIEW APEX_040000.APEX_UI_DEFAULTS_TABLES IS 'The User Interface Defaults for the tables within this schema.  Used by the wizards when generating applications.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_TABLES.SCHEMA IS 'Schema owning table.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_TABLES.TABLE_NAME IS 'Name of table in the schema.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_TABLES.FORM_REGION_TITLE IS 'When creating a form based upon this table, this title will be used as the resulting region title.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_TABLES.REPORT_REGION_TITLE IS 'When creating a report or tabular form based upon this table, this title will be used as the resulting region title.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_TABLES.CREATED_BY IS 'Auditing; user that created the record.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_TABLES.CREATED_ON IS 'Auditing; date the record was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_TABLES.LAST_UPDATED_BY IS 'Auditing; user that last modified the record.'
/
COMMENT ON COLUMN APEX_040000.APEX_UI_DEFAULTS_TABLES.LAST_UPDATED_ON IS 'Auditing; date the record was last modified.'
/
