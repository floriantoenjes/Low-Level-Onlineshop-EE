CREATE VIEW APEX_WORKSPACE_LOG_ARCHIVE AS select
    w.short_name                           workspace,
    l.LOG_DAY,
    l.WORKSPACE_ID,
    l.APPLICATION_ID,
    l.PAGE_EVENTS,
    l.PAGE_VIEWS,
    l.PAGE_ACCEPTS,
    l.PARTIAL_PAGE_VIEWS,
    l.WEBSHEET_VIEWS,
    l.ROWS_FETCHED,
    l.IR_SEARCHES,
    l.DISTINCT_PAGES,
    l.DISTINCT_USERS,
    l.DISTINCT_SESSIONS,
    l.AVERAGE_RENDER_TIME,
    l.MEDIAN_RENDER_TIME,
    l.MAXIMUM_RENDER_TIME,
    l.TOTAL_RENDER_TIME,
    l.ERROR_COUNT,
    l.content_length
from WWV_FLOW_LOG_HISTORY l,
     wwv_flow_companies w,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (l.workspace_id in (select security_group_id from  wwv_flow_company_schemas where schema = user) or
       user in ('SYS','SYSTEM', 'APEX_040000')  or
       d.sgid = l.workspace_id) and
       l.workspace_id = w.PROVISIONING_COMPANY_ID and
      w.PROVISIONING_COMPANY_ID != 0
/
COMMENT ON VIEW APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE IS 'Page view activity is a daily summary of workspace acitivity that is retained until physically purged'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.WORKSPACE IS 'Name of Workspace that generated the page view log entry'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.LOG_DAY IS 'Day that all workspace statistics are summarized for'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.WORKSPACE_ID IS 'Identifies workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.PAGE_EVENTS IS 'Total number of page events logged for a given day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.PAGE_VIEWS IS 'Total page views for a given day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.PAGE_ACCEPTS IS 'Total page accepts for a given day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.PARTIAL_PAGE_VIEWS IS 'Total partial page views for a given day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.WEBSHEET_VIEWS IS 'Total websheet application page views for a given day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.ROWS_FETCHED IS 'Total rows fetched by apex reporting engines for a given day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.IR_SEARCHES IS 'Total not null interactive report search values logged to the activity log'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.DISTINCT_PAGES IS 'Summarized information by day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.DISTINCT_USERS IS 'Summarized information by day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.DISTINCT_SESSIONS IS 'Summarized information by day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.AVERAGE_RENDER_TIME IS 'Summarized information by day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.MEDIAN_RENDER_TIME IS 'Summarized information by day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.MAXIMUM_RENDER_TIME IS 'Summarized information by day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.TOTAL_RENDER_TIME IS 'Summarized information by day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.ERROR_COUNT IS 'Summarized information by day and workspace'
/
COMMENT ON COLUMN APEX_040000.APEX_WORKSPACE_LOG_ARCHIVE.CONTENT_LENGTH IS 'Summarized information by day and workspace'
/
