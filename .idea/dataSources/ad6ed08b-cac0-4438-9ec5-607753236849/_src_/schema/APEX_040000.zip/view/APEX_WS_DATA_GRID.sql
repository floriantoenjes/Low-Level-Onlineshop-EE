CREATE VIEW APEX_WS_DATA_GRID AS select
w.short_name                workspace,
a.id                        application_id,
a.name                      application_name,
dg.worksheet_id             interactive_report_id,
dg.id                       data_grid_id,
dg.websheet_name            data_grid_name,
dg.websheet_alias           data_grid_alias,
--
dg.created_on               ,
dg.created_by               ,
dg.updated_on               ,
dg.updated_by
from wwv_flow_ws_websheet_attr dg,
     wwv_flow_ws_applications a,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.is_apex$_schema = 'Y' and
      a.security_group_id = w.PROVISIONING_COMPANY_ID and
      a.security_group_id = dg.security_group_id and
      a.id = dg.ws_app_id and
      dg.websheet_type = 'DATA' and
      w.provisioning_company_id != 0
/
COMMENT ON VIEW APEX_040000.APEX_WS_DATA_GRID IS 'Websheet Data Grid definition'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.WORKSPACE IS 'A work area mapped to one or more database schemas'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.APPLICATION_NAME IS 'Identifies the application'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.INTERACTIVE_REPORT_ID IS 'ID of the interactive report'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.DATA_GRID_ID IS 'ID of the Data Grid'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.DATA_GRID_NAME IS 'Name of the Data Grid'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.DATA_GRID_ALIAS IS 'An alternate alphanumeric Data Grid identifier'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.CREATED_ON IS 'Auditing; date the record was created.'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.CREATED_BY IS 'Auditing; user that created the record.'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.UPDATED_ON IS 'Auditing; date the record was last modified.'
/
COMMENT ON COLUMN APEX_040000.APEX_WS_DATA_GRID.UPDATED_BY IS 'Auditing; user that last modified the record.'
/
