CREATE VIEW WWV_FLOW_MINUTES_5 AS select (i-1)*5 from wwv_flow_dual100 where i < 13
/
