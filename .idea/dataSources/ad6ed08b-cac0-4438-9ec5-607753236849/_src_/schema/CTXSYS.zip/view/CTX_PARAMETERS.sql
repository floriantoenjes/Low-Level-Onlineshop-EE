CREATE VIEW CTX_PARAMETERS AS select par_name, par_value
     from dr$parameter
/
