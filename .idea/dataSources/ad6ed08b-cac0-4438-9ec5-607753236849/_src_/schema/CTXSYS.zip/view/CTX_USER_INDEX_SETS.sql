CREATE VIEW CTX_USER_INDEX_SETS AS select
   ixs_name
from dr$index_set
where ixs_owner# = userenv('SCHEMAID')
/
