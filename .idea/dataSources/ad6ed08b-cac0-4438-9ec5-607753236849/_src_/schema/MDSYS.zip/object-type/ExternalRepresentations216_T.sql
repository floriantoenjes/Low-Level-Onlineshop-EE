CREATE TYPE         "ExternalRepresentations216_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GML" "SharedValueType201_T","CityGML" "SharedValueType201_T","KML" "SharedValueType201_T","X3D" "SharedValueType201_T","BIM" "SharedValueType201_T")FINAL INSTANTIABLE
/
