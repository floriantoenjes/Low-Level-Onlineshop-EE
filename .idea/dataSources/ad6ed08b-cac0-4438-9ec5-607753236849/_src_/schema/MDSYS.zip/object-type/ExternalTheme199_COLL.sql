CREATE TYPE         "ExternalTheme199_COLL" AS VARRAY(2147483647) OF "ExternalTheme197_T"
/
