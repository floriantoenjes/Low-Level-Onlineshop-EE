CREATE TYPE         "HierarchyParticipation175_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Parent" "Parent176_COLL")FINAL INSTANTIABLE
/
