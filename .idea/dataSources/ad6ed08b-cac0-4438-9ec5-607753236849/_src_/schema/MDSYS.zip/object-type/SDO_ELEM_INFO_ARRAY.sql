CREATE TYPE SDO_ELEM_INFO_ARRAY
                                                                      
AS VARRAY (1048576) of NUMBER
/
