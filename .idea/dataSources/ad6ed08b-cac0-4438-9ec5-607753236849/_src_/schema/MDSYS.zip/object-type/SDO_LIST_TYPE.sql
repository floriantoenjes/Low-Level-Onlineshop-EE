CREATE type SDO_List_Type
                                                                      
as VARRAY (2147483647) of Number
/
