CREATE TYPE SDO_STRING2_ARRAYSET
                                                                      
AS VARRAY(2147483647) OF SDO_STRING2_ARRAY
/
