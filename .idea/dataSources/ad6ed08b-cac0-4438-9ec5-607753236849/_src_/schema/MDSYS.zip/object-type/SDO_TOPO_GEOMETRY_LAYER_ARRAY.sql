CREATE Type SDO_Topo_Geometry_Layer_Array
                                                                      
as VARRAY (1000) of SDO_Topo_Geometry_Layer
/
