CREATE TYPE ST_CURVE_ARRAY
                                      
AS VARRAY(1048576) OF ST_CURVE
/
