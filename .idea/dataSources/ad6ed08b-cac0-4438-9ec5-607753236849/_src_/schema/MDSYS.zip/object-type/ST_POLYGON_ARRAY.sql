CREATE TYPE ST_POLYGON_ARRAY
                                      
AS VARRAY(1048576) OF ST_POLYGON
/
