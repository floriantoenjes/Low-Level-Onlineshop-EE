CREATE TYPE         "Style3dType200_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Color" "SharedValueType201_T","Texture" "TextureType202_T","ModelStyle" "FeatureReferenceType191_T","Normals" "Normals203_T")NOT FINAL INSTANTIABLE
/
