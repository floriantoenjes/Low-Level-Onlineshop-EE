CREATE TYPE         "TextureType202_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","TextureBLOB" "SharedValueType201_T","TextureCoordinates" "SharedValueType201_T")NOT FINAL INSTANTIABLE
/
