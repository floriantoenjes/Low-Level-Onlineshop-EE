CREATE type V81_index_obj_array as VARRAY (1000000) of V81_index_object;
/
