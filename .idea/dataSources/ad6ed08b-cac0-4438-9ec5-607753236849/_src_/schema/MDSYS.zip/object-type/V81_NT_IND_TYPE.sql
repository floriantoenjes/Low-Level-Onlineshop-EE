CREATE type V81_nt_ind_type as table of V81_index_object;
/
