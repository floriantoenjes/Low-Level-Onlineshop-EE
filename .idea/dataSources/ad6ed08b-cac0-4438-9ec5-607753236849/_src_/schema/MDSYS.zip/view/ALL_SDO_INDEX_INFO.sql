CREATE VIEW ALL_SDO_INDEX_INFO AS select SDO_INDEX_OWNER, SDO_INDEX_NAME index_name,  table_owner, table_name,
       REPLACE(sdo_column_name, '"')  column_name,
       SDO_INDEX_TYPE, SDO_INDEX_TABLE, SDO_INDEX_STATUS
 from all_sdo_index_metadata,
     all_indexes
 where index_name = sdo_index_name and owner=sdo_index_owner
/
