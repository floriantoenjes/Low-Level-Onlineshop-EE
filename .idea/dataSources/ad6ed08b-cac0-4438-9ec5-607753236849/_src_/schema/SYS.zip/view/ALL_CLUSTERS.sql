CREATE VIEW ALL_CLUSTERS AS select u.name, o.name, ts.name,
          mod(c.pctfree$, 100),
          decode(bitand(ts.flags, 32), 32, to_number(NULL), c.pctused$),
          c.size$,c.initrans,c.maxtrans,
          s.iniexts * ts.blocksize, s.extsize * ts.blocksize,
          s.minexts, s.maxexts,
          decode(bitand(ts.flags, 3), 1, to_number(NULL),
                                      s.extpct),
          decode(bitand(ts.flags, 32), 32, to_number(NULL),
           decode(s.lists, 0, 1, s.lists)),
          decode(bitand(ts.flags, 32), 32, to_number(NULL),
           decode(s.groups, 0, 1, s.groups)),
          c.avgchn, decode(c.hashkeys, 0, 'INDEX', 'HASH'),
          decode(c.hashkeys, 0, NULL,
                 decode(c.func, 0, 'COLUMN', 1, 'DEFAULT',
                                2, 'HASH EXPRESSION', 3, 'DEFAULT2', NULL)),
          c.hashkeys,
          lpad(decode(c.degree, 32767, 'DEFAULT', nvl(c.degree,1)),10),
          lpad(decode(c.instances, 32767, 'DEFAULT', nvl(c.instances,1)),10),
          lpad(decode(bitand(c.flags, 8), 8, 'Y', 'N'), 5),
          decode(bitand(s.cachehint, 3), 1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
          decode(bitand(s.cachehint, 12)/4, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
          decode(bitand(s.cachehint, 48)/16, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
          lpad(decode(bitand(c.flags, 65536), 65536, 'Y', 'N'), 5),
          decode(bitand(c.flags, 8388608), 8388608, 'ENABLED', 'DISABLED')
from sys.user$ u, sys.ts$ ts, sys.seg$ s, sys.clu$ c, sys.obj$ o
where o.owner# = u.user#
  and o.obj#   = c.obj#
  and c.ts#    = ts.ts#
  and c.ts#    = s.ts#
  and c.file#  = s.file#
  and c.block# = s.block#
  and (o.owner# = userenv('SCHEMAID')
       or  /* user has system privilages */
         exists (select null from v$enabledprivs
                 where priv_number in (-61 /* CREATE ANY CLUSTER */,
                                       -62 /* ALTER ANY CLUSTER */,
                                       -63 /* DROP ANY CLUSTER */ )
                )
      )
/
COMMENT ON VIEW SYS.ALL_CLUSTERS IS 'Description of clusters accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.OWNER IS 'Owner of the cluster'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.CLUSTER_NAME IS 'Name of the cluster'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.TABLESPACE_NAME IS 'Name of the tablespace containing the cluster'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.PCT_FREE IS 'Minimum percentage of free space in a block'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.PCT_USED IS 'Minimum percentage of used space in a block'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.KEY_SIZE IS 'Estimated size of cluster key plus associated rows'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.INI_TRANS IS 'Initial number of transactions'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.MAX_TRANS IS 'Maximum number of transactions'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.INITIAL_EXTENT IS 'Size of the initial extent in bytes'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.NEXT_EXTENT IS 'Size of secondary extents in bytes'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.MIN_EXTENTS IS 'Minimum number of extents allowed in the segment'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.MAX_EXTENTS IS 'Maximum number of extents allowed in the segment'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.PCT_INCREASE IS 'Percentage increase in extent size'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.FREELISTS IS 'Number of process freelists allocated in this segment'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.FREELIST_GROUPS IS 'Number of freelist groups allocated in this segment'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.AVG_BLOCKS_PER_KEY IS 'Average number of blocks containing rows with a given cluster key'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.CLUSTER_TYPE IS 'Type of cluster: b-tree index or hash'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.FUNCTION IS 'If a hash cluster, the hash function'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.HASHKEYS IS 'If a hash cluster, the number of hash keys (hash buckets)'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.DEGREE IS 'The number of threads per instance for scanning the cluster'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.INSTANCES IS 'The number of instances across which the cluster is to be scanned'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.CACHE IS 'Whether the cluster is to be cached in the buffer cache'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.BUFFER_POOL IS 'The default buffer pool to be used for cluster blocks'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.FLASH_CACHE IS 'The default flash cache hint to be used for cluster blocks'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.CELL_FLASH_CACHE IS 'The default cell flash cache hint to be used for cluster blocks'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.SINGLE_TABLE IS 'Whether the cluster can contain only a single table'
/
COMMENT ON COLUMN SYS.ALL_CLUSTERS.DEPENDENCIES IS 'Should we keep track of row level dependencies?'
/
