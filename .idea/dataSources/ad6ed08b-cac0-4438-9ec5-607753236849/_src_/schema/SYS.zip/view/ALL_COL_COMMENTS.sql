CREATE VIEW ALL_COL_COMMENTS AS select u.name, o.name, c.name, co.comment$
from sys."_CURRENT_EDITION_OBJ" o, sys.col$ c, sys.user$ u, sys.com$ co
where o.owner# = u.user#
  and o.type# in (2, 4, 5)
  and o.obj# = c.obj#
  and c.obj# = co.obj#(+)
  and c.intcol# = co.col#(+)
  and bitand(c.property, 32) = 0 /* not hidden column */
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
         (select obj#
          from sys.objauth$
          where grantee# in ( select kzsrorol
                              from x$kzsro
                            )
          )
       or
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */))
      )
/
COMMENT ON VIEW SYS.ALL_COL_COMMENTS IS 'Comments on columns of accessible tables and views'
/
COMMENT ON COLUMN SYS.ALL_COL_COMMENTS.OWNER IS 'Owner of the object'
/
COMMENT ON COLUMN SYS.ALL_COL_COMMENTS.TABLE_NAME IS 'Name of the object'
/
COMMENT ON COLUMN SYS.ALL_COL_COMMENTS.COLUMN_NAME IS 'Name of the column'
/
COMMENT ON COLUMN SYS.ALL_COL_COMMENTS.COMMENTS IS 'Comment on the column'
/
