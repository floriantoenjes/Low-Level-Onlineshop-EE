CREATE VIEW ALL_DB_LINKS AS select u.name, l.name, l.userid, l.host, l.ctime
from sys.link$ l, sys.user$ u
where l.owner# in ( select kzsrorol from x$kzsro )
  and l.owner# = u.user#
/
COMMENT ON VIEW SYS.ALL_DB_LINKS IS 'Database links accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_DB_LINKS.DB_LINK IS 'Name of the database link'
/
COMMENT ON COLUMN SYS.ALL_DB_LINKS.USERNAME IS 'Name of user to log on as'
/
COMMENT ON COLUMN SYS.ALL_DB_LINKS.HOST IS 'SQL*Net string for connect'
/
COMMENT ON COLUMN SYS.ALL_DB_LINKS.CREATED IS 'Creation time of the database link'
/
