CREATE VIEW ALL_DIM_CHILD_OF AS select d."OWNER",d."DIMENSION_NAME",d."HIERARCHY_NAME",d."POSITION",d."CHILD_LEVEL_NAME",d."JOIN_KEY_ID",d."PARENT_LEVEL_NAME" from dba_dim_child_of d, sys.obj$ o, sys.user$ u
where o.owner#         = u.user#
  and d.dimension_name = o.name
  and d.owner          = u.name
  and o.type#          = 43                     /* dimension */
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-215 /* CREATE ANY DIMENSION */,
                                       -216 /* ALTER ANY DIMENSION */,
                                       -217 /* DROP ANY DIMENSION */)
                 )
      )
/
COMMENT ON VIEW SYS.ALL_DIM_CHILD_OF IS 'Representaion of a 1:n hierarchical relationship between a pair of levels in
 a dimension'
/
COMMENT ON COLUMN SYS.ALL_DIM_CHILD_OF.OWNER IS 'Owner of the dimension'
/
COMMENT ON COLUMN SYS.ALL_DIM_CHILD_OF.DIMENSION_NAME IS 'Name of the dimension'
/
COMMENT ON COLUMN SYS.ALL_DIM_CHILD_OF.HIERARCHY_NAME IS 'Name of the hierarchy'
/
COMMENT ON COLUMN SYS.ALL_DIM_CHILD_OF.POSITION IS 'Hierarchical position within this hierarchy, position 1 being
 the most detailed'
/
COMMENT ON COLUMN SYS.ALL_DIM_CHILD_OF.CHILD_LEVEL_NAME IS 'Name of the child-side level of this 1:n relationship'
/
COMMENT ON COLUMN SYS.ALL_DIM_CHILD_OF.JOIN_KEY_ID IS 'Keys that join child to the parent'
/
COMMENT ON COLUMN SYS.ALL_DIM_CHILD_OF.PARENT_LEVEL_NAME IS 'Name of the parent-side level of this 1:n relationship'
/
