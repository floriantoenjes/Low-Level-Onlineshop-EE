CREATE VIEW ALL_EDITIONS AS select o.name, po.name, decode(bitand(e.flags,1),1,'NO','YES')
from sys.obj$ o, sys.edition$ e, sys.obj$ po
where o.obj# = e.obj#
  and po.obj# (+)= e.p_obj#
/
COMMENT ON VIEW SYS.ALL_EDITIONS IS 'Describes all editions in the database'
/
COMMENT ON COLUMN SYS.ALL_EDITIONS.EDITION_NAME IS 'Name of the edition'
/
COMMENT ON COLUMN SYS.ALL_EDITIONS.PARENT_EDITION_NAME IS 'Name of the parent edition for this edition'
/
COMMENT ON COLUMN SYS.ALL_EDITIONS.USABLE IS 'A value of ''YES'' means edition is usable and ''NO'' means unusable'
/
