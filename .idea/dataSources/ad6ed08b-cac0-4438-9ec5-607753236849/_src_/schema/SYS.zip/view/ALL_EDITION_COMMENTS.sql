CREATE VIEW ALL_EDITION_COMMENTS AS select o.name, c.comment$
from sys.obj$ o, sys.com$ c
where o.obj# = c.obj# (+)
  and o.type# = 57
/
COMMENT ON VIEW SYS.ALL_EDITION_COMMENTS IS 'Describes comments on all editions in the database'
/
COMMENT ON COLUMN SYS.ALL_EDITION_COMMENTS.EDITION_NAME IS 'Name of the edition'
/
COMMENT ON COLUMN SYS.ALL_EDITION_COMMENTS.COMMENTS IS 'Edition comments'
/
