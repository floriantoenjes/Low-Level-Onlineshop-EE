CREATE VIEW ALL_ENCRYPTED_COLUMNS AS select u.name, o.name, c.name,
          case e.ENCALG when 1 then '3 Key Triple DES 168 bits key'
                        when 2 then 'AES 128 bits key'
                        when 3 then 'AES 192 bits key'
                        when 4 then 'AES 256 bits key'
                        else 'Internal Err'
          end,
          decode(bitand(c.property, 536870912), 0, 'YES', 'NO'),
          case e.INTALG when 1 then 'SHA-1'
                        when 2 then 'NOMAC'
                        else 'Internal Err'
          end
   from user$ u, obj$ o, col$ c, enc$ e
   where e.obj#=o.obj# and o.owner#=u.user# and bitand(flags, 128)=0 and
         e.obj#=c.obj# and bitand(c.property, 67108864) = 67108864 and
         (o.owner# = userenv('SCHEMAID')
          or
          e.obj# in (select obj# from sys.objauth$ where grantee# in
                        (select kzsrorol from x$kzsro))
          or
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */))
          )
/
COMMENT ON VIEW SYS.ALL_ENCRYPTED_COLUMNS IS 'Encryption information on all accessible columns'
/
COMMENT ON COLUMN SYS.ALL_ENCRYPTED_COLUMNS.OWNER IS 'Owner of the table'
/
COMMENT ON COLUMN SYS.ALL_ENCRYPTED_COLUMNS.TABLE_NAME IS 'Name of the table'
/
COMMENT ON COLUMN SYS.ALL_ENCRYPTED_COLUMNS.COLUMN_NAME IS 'Name of the column'
/
COMMENT ON COLUMN SYS.ALL_ENCRYPTED_COLUMNS.ENCRYPTION_ALG IS 'Encryption algorithm used for the column'
/
COMMENT ON COLUMN SYS.ALL_ENCRYPTED_COLUMNS.SALT IS 'Is this column encrypted with salt? YES or NO'
/
COMMENT ON COLUMN SYS.ALL_ENCRYPTED_COLUMNS.INTEGRITY_ALG IS 'Integrity algorithm used for the column'
/
