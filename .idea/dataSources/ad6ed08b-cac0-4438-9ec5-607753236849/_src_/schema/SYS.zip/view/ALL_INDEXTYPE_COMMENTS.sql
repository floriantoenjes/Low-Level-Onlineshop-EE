CREATE VIEW ALL_INDEXTYPE_COMMENTS AS select  u.name, o.name, c.comment$
from    sys.obj$ o, sys.user$ u, sys.indtypes$ i, sys.com$ c
where   o.obj# = i.obj# and u.user# = o.owner# and c.obj# = i.obj# and
( o.owner# = userenv ('SCHEMAID')
    or
    o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or exists (select null from v$enabledprivs
                  where priv_number in (-205 /* CREATE INDEXTYPE */,
                                        -206 /* CREATE ANY INDEXTYPE */,
                                        -207 /* ALTER ANY INDEXTYPE */,
                                        -208 /* DROP ANY INDEXTYPE */)
                 )
 )
/
COMMENT ON VIEW SYS.ALL_INDEXTYPE_COMMENTS IS 'Comments for user-defined indextypes'
/
COMMENT ON COLUMN SYS.ALL_INDEXTYPE_COMMENTS.OWNER IS 'Owner of the user-defined indextype'
/
COMMENT ON COLUMN SYS.ALL_INDEXTYPE_COMMENTS.INDEXTYPE_NAME IS 'Name of the user-defined indextype'
/
COMMENT ON COLUMN SYS.ALL_INDEXTYPE_COMMENTS.COMMENTS IS 'Comment for the user-defined indextype'
/
