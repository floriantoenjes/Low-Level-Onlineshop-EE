CREATE VIEW ALL_IND_EXPRESSIONS AS select io.name, idx.name, bo.name, base.name, c.default$, ic.pos#
from sys.col$ c, sys.obj$ idx, sys.obj$ base, sys.icol$ ic,
     sys.user$ io, sys.user$ bo, sys.ind$ i
where bitand(ic.spare1,1) = 1       /* an expression */
  and (bitand(i.property,1024) = 0) /* not bmji */
  and ic.bo# = c.obj#
  and ic.intcol# = c.intcol#
  and ic.bo# = base.obj#
  and io.user# = idx.owner#
  and bo.user# = base.owner#
  and ic.obj# = idx.obj#
  and idx.obj# = i.obj#
  and i.type# in (1, 2, 3, 4, 6, 7, 9)
  and (idx.owner# = userenv('SCHEMAID') or
       base.owner# = userenv('SCHEMAID')
       or
       base.obj# in ( select obj#
                     from sys.objauth$
                     where grantee# in ( select kzsrorol
                                         from x$kzsro
                                       )
                   )
        or
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
       )
/
COMMENT ON VIEW SYS.ALL_IND_EXPRESSIONS IS 'FUNCTIONAL INDEX EXPRESSIONs on accessible TABLES'
/
COMMENT ON COLUMN SYS.ALL_IND_EXPRESSIONS.INDEX_OWNER IS 'Index owner'
/
COMMENT ON COLUMN SYS.ALL_IND_EXPRESSIONS.INDEX_NAME IS 'Index name'
/
COMMENT ON COLUMN SYS.ALL_IND_EXPRESSIONS.TABLE_OWNER IS 'Table or cluster owner'
/
COMMENT ON COLUMN SYS.ALL_IND_EXPRESSIONS.TABLE_NAME IS 'Table or cluster name'
/
COMMENT ON COLUMN SYS.ALL_IND_EXPRESSIONS.COLUMN_EXPRESSION IS 'Functional index expression defining the column'
/
COMMENT ON COLUMN SYS.ALL_IND_EXPRESSIONS.COLUMN_POSITION IS 'Position of column or attribute within index'
/
