CREATE VIEW ALL_NESTED_TABLE_COLS AS select u.name, o.name,
       c.name,
       decode(c.type#, 1, decode(c.charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
                       2, decode(c.scale, null,
                                 decode(c.precision#, null, 'NUMBER', 'FLOAT'),
                                 'NUMBER'),
                       8, 'LONG',
                       9, decode(c.charsetform, 2, 'NCHAR VARYING', 'VARCHAR'),
                       12, 'DATE',
                       23, 'RAW', 24, 'LONG RAW',
                       58, nvl2(ac.synobj#, (select o.name from obj$ o
                                where o.obj#=ac.synobj#), ot.name),
                       69, 'ROWID',
                       96, decode(c.charsetform, 2, 'NCHAR', 'CHAR'),
                       100, 'BINARY_FLOAT',
                       101, 'BINARY_DOUBLE',
                       105, 'MLSLABEL',
                       106, 'MLSLABEL',
                       111, nvl2(ac.synobj#, (select o.name from obj$ o
                                 where o.obj#=ac.synobj#), ot.name),
                       112, decode(c.charsetform, 2, 'NCLOB', 'CLOB'),
                       113, 'BLOB', 114, 'BFILE', 115, 'CFILE',
                       121, nvl2(ac.synobj#, (select o.name from obj$ o
                                 where o.obj#=ac.synobj#), ot.name),
                       122, nvl2(ac.synobj#, (select o.name from obj$ o
                                 where o.obj#=ac.synobj#), ot.name),
                       123, nvl2(ac.synobj#, (select o.name from obj$ o
                                 where o.obj#=ac.synobj#), ot.name),
                       178, 'TIME(' ||c.scale|| ')',
                       179, 'TIME(' ||c.scale|| ')' || ' WITH TIME ZONE',
                       180, 'TIMESTAMP(' ||c.scale|| ')',
                       181, 'TIMESTAMP(' ||c.scale|| ')' || ' WITH TIME ZONE',
                       231, 'TIMESTAMP(' ||c.scale|| ')' || ' WITH LOCAL TIME ZONE',
                       182, 'INTERVAL YEAR(' ||c.precision#||') TO MONTH',
                       183, 'INTERVAL DAY(' ||c.precision#||') TO SECOND(' ||
                             c.scale || ')',
                       208, 'UROWID',
                       'UNDEFINED'),
       decode(c.type#, 111, 'REF'),
       nvl2(ac.synobj#, (select u.name from "_BASE_USER" u, obj$ o
            where o.owner#=u.user# and o.obj#=ac.synobj#), ut.name),
       c.length, c.precision#, c.scale,
       decode(sign(c.null$),-1,'D', 0, 'Y', 'N'),
       decode(c.col#, 0, to_number(null), c.col#), c.deflength,
       c.default$, h.distcnt,
       case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
            then h.lowval
            else null
       end,
       case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
            then h.hival
            else null
       end,
       h.density, h.null_cnt,
       case when nvl(h.distcnt,0) = 0 then h.distcnt
            when h.row_cnt = 0 then 1
	    when (h.bucket_cnt > 255
                  or
                  (h.bucket_cnt > h.distcnt
                   and h.row_cnt = h.distcnt
                   and h.density*h.bucket_cnt < 1))
                then h.row_cnt
            else h.bucket_cnt
       end,
       h.timestamp#, h.sample_size,
       decode(c.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(c.charsetid),
                             4, 'ARG:'||c.charsetid),
       decode(c.charsetid, 0, to_number(NULL),
                           nls_charset_decl_len(c.length, c.charsetid)),
       decode(bitand(h.spare2, 2), 2, 'YES', 'NO'),
       decode(bitand(h.spare2, 1), 1, 'YES', 'NO'),
       h.avgcln,
       c.spare3,
       decode(c.type#, 1, decode(bitand(c.property, 8388608), 0, 'B', 'C'),
                      96, decode(bitand(c.property, 8388608), 0, 'B', 'C'),
                      null),
       decode(bitand(ac.flags, 128), 128, 'YES', 'NO'),
       decode(o.status, 1, decode(bitand(ac.flags, 256), 256, 'NO', 'YES'),
                        decode(bitand(ac.flags, 2), 2, 'NO',
                               decode(bitand(ac.flags, 4), 4, 'NO',
                                      decode(bitand(ac.flags, 8), 8, 'NO',
                                             'N/A')))),
       decode(c.property, 0, 'NO', decode(bitand(c.property, 32), 32, 'YES',
                                          'NO')),
       decode(c.property, 0, 'NO', decode(bitand(c.property, 8), 8, 'YES',
                                          'NO')),
       decode(c.segcol#, 0, to_number(null), c.segcol#), c.intcol#,
       case when nvl(h.row_cnt,0) = 0 then 'NONE'
            when (h.bucket_cnt > 255
                  or
                  (h.bucket_cnt > h.distcnt and h.row_cnt = h.distcnt
                   and h.density*h.bucket_cnt < 1))
                then 'FREQUENCY'
            else 'HEIGHT BALANCED'
       end,
       decode(bitand(c.property, 1024), 1024,
              (select decode(bitand(cl.property, 1), 1, rc.name, cl.name)
               from sys.col$ cl, attrcol$ rc where cl.intcol# = c.intcol#-1
               and cl.obj# = c.obj# and c.obj# = rc.obj#(+) and
               cl.intcol# = rc.intcol#(+)),
              decode(bitand(c.property, 1), 0, c.name,
                     (select tc.name from sys.attrcol$ tc
                      where c.obj# = tc.obj# and c.intcol# = tc.intcol#)))
from sys.col$ c, sys.obj$ o, sys.hist_head$ h, sys.user$ u,
     sys.coltype$ ac, sys.obj$ ot, sys."_BASE_USER" ut, sys.tab$ t
where o.obj# = c.obj#
  and o.owner# = u.user#
  and c.obj# = h.obj#(+) and c.intcol# = h.intcol#(+)
  and c.obj# = ac.obj#(+) and c.intcol# = ac.intcol#(+)
  and ac.toid = ot.oid$(+)
  and ot.type#(+) = 13
  and ot.owner# = ut.user#(+)
  and o.obj# = t.obj#
  and bitand(t.property, 8192) = 8192        /* nested tables */
  and (o.owner# = userenv('SCHEMAID')
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                         from x$kzsro
                                       )
                  )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                  )
       )
/
COMMENT ON VIEW SYS.ALL_NESTED_TABLE_COLS IS 'Columns of nested tables'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.TABLE_NAME IS 'Nested table name'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.COLUMN_NAME IS 'Column name'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.DATA_TYPE IS 'Datatype of the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.DATA_TYPE_MOD IS 'Datatype modifier of the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.DATA_TYPE_OWNER IS 'Owner of the datatype of the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.DATA_LENGTH IS 'Length of the column in bytes'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.DATA_PRECISION IS 'Length: decimal digits (NUMBER) or binary digits (FLOAT)'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.DATA_SCALE IS 'Digits to right of decimal point in a number'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.NULLABLE IS 'Does column allow NULL values?'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.COLUMN_ID IS 'Sequence number of the column as created'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.DEFAULT_LENGTH IS 'Length of default value for the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.DATA_DEFAULT IS 'Default value for the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.NUM_DISTINCT IS 'The number of distinct values in the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.LOW_VALUE IS 'The low value in the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.HIGH_VALUE IS 'The high value in the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.DENSITY IS 'The density of the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.NUM_NULLS IS 'The number of nulls in the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.NUM_BUCKETS IS 'The number of buckets in histogram for the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.LAST_ANALYZED IS 'The date of the most recent time this column was analyzed'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.SAMPLE_SIZE IS 'The sample size used in analyzing this column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.CHARACTER_SET_NAME IS 'Character set name'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.CHAR_COL_DECL_LENGTH IS 'Declaration length of character type column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.GLOBAL_STATS IS 'Are the statistics calculated without merging underlying partitions?'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.USER_STATS IS 'Were the statistics entered directly by the user?'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.AVG_COL_LEN IS 'The average length of the column in bytes'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.CHAR_LENGTH IS 'The maximum length of the column in characters'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.CHAR_USED IS 'C if maximum length is specified in characters, B if in bytes'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.V80_FMT_IMAGE IS 'Is column data in 8.0 image format?'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.DATA_UPGRADED IS 'Has column data been upgraded to the latest type version format?'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.HIDDEN_COLUMN IS 'Is this a hidden column?'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.VIRTUAL_COLUMN IS 'Is this a virtual column?'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.SEGMENT_COLUMN_ID IS 'Sequence number of the column in the segment'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.INTERNAL_COLUMN_ID IS 'Internal sequence number of the column'
/
COMMENT ON COLUMN SYS.ALL_NESTED_TABLE_COLS.QUALIFIED_COL_NAME IS 'Qualified column name'
/
