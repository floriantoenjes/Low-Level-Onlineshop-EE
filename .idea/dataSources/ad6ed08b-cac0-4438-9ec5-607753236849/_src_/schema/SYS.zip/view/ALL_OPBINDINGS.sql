CREATE VIEW ALL_OPBINDINGS AS select   c.name, b.name, a.bind#, a.functionname, a.returnschema,
         a.returntype, a.impschema, a.imptype,
        decode(bitand(a.property,31), 1, 'WITH INDEX CONTEXT',
               3 , 'COMPUTE ANCILLARY DATA', 4 , 'ANCILLARY TO' ,
               16 , 'WITH COLUMN CONTEXT' ,
               17,  'WITH INDEX, COLUMN CONTEXT',
               19, 'COMPUTE ANCILLARY DATA, WITH COLUMN CONTEXT')
   from  sys.opbinding$ a, sys.obj$ b, sys.user$ c where
  a.obj# = b.obj# and b.owner# = c.user#
  and ( b.owner# = userenv ('SCHEMAID')
    or
    b.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or exists (select null from v$enabledprivs
                  where priv_number in (-200 /* CREATE OPERATOR */,
                                        -201 /* CREATE ANY OPERATOR */,
                                        -202 /* ALTER ANY OPERATOR */,
                                        -203 /* DROP ANY OPERATOR */,
                                        -204 /* EXECUTE OPERATOR */)
                 )
      )
/
COMMENT ON VIEW SYS.ALL_OPBINDINGS IS 'All binding functions for operators available to the user'
/
COMMENT ON COLUMN SYS.ALL_OPBINDINGS.OWNER IS 'Owner of the operator'
/
COMMENT ON COLUMN SYS.ALL_OPBINDINGS.OPERATOR_NAME IS 'Name of the operator'
/
COMMENT ON COLUMN SYS.ALL_OPBINDINGS.BINDING# IS 'Binding# of the operator'
/
COMMENT ON COLUMN SYS.ALL_OPBINDINGS.FUNCTION_NAME IS 'Name of the binding function or method as specified by the user'
/
COMMENT ON COLUMN SYS.ALL_OPBINDINGS.RETURN_SCHEMA IS 'Name of the schema of the return type - not null only for ADTs'
/
COMMENT ON COLUMN SYS.ALL_OPBINDINGS.RETURN_TYPE IS 'Name of the return type'
/
COMMENT ON COLUMN SYS.ALL_OPBINDINGS.IMPLEMENTATION_TYPE_SCHEMA IS 'Schema of the implementation type of the indextype '
/
COMMENT ON COLUMN SYS.ALL_OPBINDINGS.IMPLEMENTATION_TYPE IS 'Implementation type of the indextype'
/
COMMENT ON COLUMN SYS.ALL_OPBINDINGS.PROPERTY IS 'Property of the operator binding'
/
