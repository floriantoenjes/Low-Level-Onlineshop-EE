CREATE VIEW ALL_PENDING_CONV_TABLES AS select u.name, o.name
from sys.obj$ o, user$ u
  where o.type# = 2 and o.status = 5
  and bitand(o.flags, 4096) = 4096  /* type evolved flg */
  and o.owner# = u.user#
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)))
/
COMMENT ON VIEW SYS.ALL_PENDING_CONV_TABLES IS 'All tables accessible to the user which are not upgraded to the latest type version'
/
COMMENT ON COLUMN SYS.ALL_PENDING_CONV_TABLES.OWNER IS 'Owner of the table'
/
COMMENT ON COLUMN SYS.ALL_PENDING_CONV_TABLES.TABLE_NAME IS 'Name of the table'
/
