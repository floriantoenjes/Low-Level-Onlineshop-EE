CREATE VIEW ALL_SEQUENCES AS select u.name, o.name,
      s.minvalue, s.maxvalue, s.increment$,
      decode (s.cycle#, 0, 'N', 1, 'Y'),
      decode (s.order$, 0, 'N', 1, 'Y'),
      s.cache, s.highwater
from sys.seq$ s, sys.obj$ o, sys.user$ u
where u.user# = o.owner#
  and o.obj# = s.obj#
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
        or
         exists (select null from v$enabledprivs
                 where priv_number = -109 /* SELECT ANY SEQUENCE */
                 )
      )
/
COMMENT ON VIEW SYS.ALL_SEQUENCES IS 'Description of SEQUENCEs accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_SEQUENCES.SEQUENCE_OWNER IS 'Name of the owner of the sequence'
/
COMMENT ON COLUMN SYS.ALL_SEQUENCES.SEQUENCE_NAME IS 'SEQUENCE name'
/
COMMENT ON COLUMN SYS.ALL_SEQUENCES.MIN_VALUE IS 'Minimum value of the sequence'
/
COMMENT ON COLUMN SYS.ALL_SEQUENCES.MAX_VALUE IS 'Maximum value of the sequence'
/
COMMENT ON COLUMN SYS.ALL_SEQUENCES.INCREMENT_BY IS 'Value by which sequence is incremented'
/
COMMENT ON COLUMN SYS.ALL_SEQUENCES.CYCLE_FLAG IS 'Does sequence wrap around on reaching limit?'
/
COMMENT ON COLUMN SYS.ALL_SEQUENCES.ORDER_FLAG IS 'Are sequence numbers generated in order?'
/
COMMENT ON COLUMN SYS.ALL_SEQUENCES.CACHE_SIZE IS 'Number of sequence numbers to cache'
/
COMMENT ON COLUMN SYS.ALL_SEQUENCES.LAST_NUMBER IS 'Last sequence number written to disk'
/
