CREATE VIEW ALL_STORED_SETTINGS AS SELECT u.name, o.name, o.obj#,
DECODE(o.type#,
        7, 'PROCEDURE',
        8, 'FUNCTION',
        9, 'PACKAGE',
       11, 'PACKAGE BODY',
       12, 'TRIGGER',
       13, 'TYPE',
       14, 'TYPE BODY',
       'UNDEFINED'),
p.param, p.value
FROM sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.settings$ p
WHERE o.owner# = u.user#
AND o.linkname is null
AND (o.type# in (7, 8, 9, 11, 12, 14) or (o.type# = 13 and o.subname is null))
AND p.obj# = o.obj#
AND (
    o.owner# in (userenv('SCHEMAID'), 1 /* PUBLIC */)
    or
    (
      (
         (
          (o.type# = 7 or o.type# = 8 or o.type# = 9 or
           (o.type# = 13 and o.subname is null))
          and
          o.obj# in (select obj# from sys.objauth$
                     where grantee# in (select kzsrorol from x$kzsro)
                       and privilege# in (12 /* EXECUTE */,
                                          26 /* DEBUG */))
        )
        or
        exists
        (
          select null from sys.sysauth$
          where grantee# in (select kzsrorol from x$kzsro)
          and
          (
            (
              /* procedure */
              (o.type# = 7 or o.type# = 8 or o.type# = 9)
              and
              (
                privilege# = -144 /* EXECUTE ANY PROCEDURE */
                or
                privilege# = -141 /* CREATE ANY PROCEDURE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* package body */
              o.type# = 11 and
              (
                privilege# = -141 /* CREATE ANY PROCEDURE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* type */
              o.type# = 13 and o.subname is null
              and
              (
                privilege# = -184 /* EXECUTE ANY TYPE */
                or
                privilege# = -181 /* CREATE ANY TYPE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* type body */
              o.type# = 14 and
              (
                privilege# = -181 /* CREATE ANY TYPE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
          )
        )
      )
    )
  )
/
COMMENT ON VIEW SYS.ALL_STORED_SETTINGS IS 'Parameter settings for objects accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_STORED_SETTINGS.OWNER IS 'Username of the owner of the object'
/
COMMENT ON COLUMN SYS.ALL_STORED_SETTINGS.OBJECT_NAME IS 'Name of the object'
/
COMMENT ON COLUMN SYS.ALL_STORED_SETTINGS.OBJECT_ID IS 'Object number of the object'
/
COMMENT ON COLUMN SYS.ALL_STORED_SETTINGS.OBJECT_TYPE IS 'Type of the object'
/
COMMENT ON COLUMN SYS.ALL_STORED_SETTINGS.PARAM_NAME IS 'Name of the parameter'
/
COMMENT ON COLUMN SYS.ALL_STORED_SETTINGS.PARAM_VALUE IS 'Value of the parameter'
/
