CREATE VIEW ALL_SUMMAP AS select XID, COMMIT_SCN from sys.snap_xcmt$
/
COMMENT ON VIEW SYS.ALL_SUMMAP IS 'mapping entries of transaction ID and commit SCN accessible to the user'
/
COMMENT ON COLUMN SYS.ALL_SUMMAP.XID IS 'The ID of a transaction'
/
COMMENT ON COLUMN SYS.ALL_SUMMAP.COMMIT_SCN IS 'The commit SCN of a transaction'
/
