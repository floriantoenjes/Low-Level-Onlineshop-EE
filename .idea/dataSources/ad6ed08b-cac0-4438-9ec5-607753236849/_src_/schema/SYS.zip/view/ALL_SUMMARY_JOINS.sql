CREATE VIEW ALL_SUMMARY_JOINS AS select u.name, o.name,
       u1.name, o1.name, c1.name, '=',
       u2.name, o2.name, c2.name
from sys.sumjoin$ sj, sys.obj$ o, sys.user$ u,
     sys.obj$ o1, sys.user$ u1, sys.col$ c1,
     sys.obj$ o2, sys.user$ u2, sys.col$ c2,
     sys.sum$ s
where sj.sumobj# = o.obj#
  AND o.owner# = u.user#
  AND sj.tab1obj# = o1.obj#
  AND o1.owner# = u1.user#
  AND sj.tab1obj# = c1.obj#
  AND sj.tab1col# = c1.intcol#
  AND sj.tab2obj# = o2.obj#
  AND o2.owner# = u2.user#
  AND sj.tab2obj# = c2.obj#
  AND sj.tab2col# = c2.intcol#
  AND (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
  AND s.obj# = sj.sumobj#
  AND bitand(s.xpflags, 8388608) = 0 /* NOT REWRITE EQUIVALENCE SUMMARY */
/
