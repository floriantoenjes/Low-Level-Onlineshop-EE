CREATE VIEW ALL_SYNONYMS AS select u.name, o.name, s.owner, s.name, s.node
from sys.user$ u, sys.syn$ s, sys."_CURRENT_EDITION_OBJ" o
where o.obj# = s.obj#
  and o.type# = 5
  and o.owner# = u.user#
  and (
       o.owner# in (USERENV('SCHEMAID'), 1 /* PUBLIC */)  /* user's private, any public */
       or /* local object, and user has system privileges */
         (s.node is null /* don't know accessibility if syn is for db link */
          and exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                     )
         )
       or /* user has any privs on base object in local database */
        exists
        (select null
         from sys.objauth$ ba, sys."_CURRENT_EDITION_OBJ" bo, sys.user$ bu
         where s.node is null /* don't know accessibility if syn for db link */
           and bu.name = s.owner
           and bo.name = s.name
           and bu.user# = bo.owner#
           and ba.obj# = bo.obj#
           and (   ba.grantee# in (select kzsrorol from x$kzsro)
                or ba.grantor# = USERENV('SCHEMAID')
               )
        )
      )
union
select st.syn_owner, st.syn_name, st.base_syn_owner,
       st.base_syn_name, st.syn_node
from sys."_ALL_SYNONYMS_TREE" st
/
COMMENT ON VIEW SYS.ALL_SYNONYMS IS 'All synonyms for base objects accessible to the user and session'
/
COMMENT ON COLUMN SYS.ALL_SYNONYMS.OWNER IS 'Owner of the synonym'
/
COMMENT ON COLUMN SYS.ALL_SYNONYMS.SYNONYM_NAME IS 'Name of the synonym'
/
COMMENT ON COLUMN SYS.ALL_SYNONYMS.TABLE_OWNER IS 'Owner of the object referenced by the synonym'
/
COMMENT ON COLUMN SYS.ALL_SYNONYMS.TABLE_NAME IS 'Name of the object referenced by the synonym'
/
COMMENT ON COLUMN SYS.ALL_SYNONYMS.DB_LINK IS 'Name of the database link referenced in a remote synonym'
/
