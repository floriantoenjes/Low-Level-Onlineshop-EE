CREATE VIEW ALL_TAB_MODIFICATIONS AS select u.name, o.name, null, null,
       m.inserts, m.updates, m.deletes, m.timestamp,
       decode(bitand(m.flags,1),1,'YES','NO'),
       m.drop_segments
from sys.mon_mods_all$ m, sys.obj$ o, sys.tab$ t, sys.user$ u
where o.obj# = m.obj# and o.obj# = t.obj# and o.owner# = u.user#
      and (o.owner# = userenv('SCHEMAID')
           or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in (select kzsrorol from x$kzsro))
           or /* user has system privileges */
             exists (select null from v$enabledprivs
                       where priv_number in (-45 /* LOCK ANY TABLE */,
                                             -47 /* SELECT ANY TABLE */,
                                             -48 /* INSERT ANY TABLE */,
                                             -49 /* UPDATE ANY TABLE */,
                                             -50 /* DELETE ANY TABLE */,
                                             -165/* ANALYZE ANY */))
          )
union all
select u.name, o.name, o.subname, null,
       m.inserts, m.updates, m.deletes, m.timestamp,
       decode(bitand(m.flags,1),1,'YES','NO'),
       m.drop_segments
from sys.mon_mods_all$ m, sys.obj$ o, sys.user$ u
where o.owner# = u.user# and o.obj# = m.obj# and o.type#=19
      and (o.owner# = userenv('SCHEMAID')
           or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in (select kzsrorol from x$kzsro))
           or /* user has system privileges */
             exists (select null from v$enabledprivs
                       where priv_number in (-45 /* LOCK ANY TABLE */,
                                             -47 /* SELECT ANY TABLE */,
                                             -48 /* INSERT ANY TABLE */,
                                             -49 /* UPDATE ANY TABLE */,
                                             -50 /* DELETE ANY TABLE */,
                                             -165/* ANALYZE ANY */))
          )
union all
select u.name, o.name, o2.subname, o.subname,
       m.inserts, m.updates, m.deletes, m.timestamp,
       decode(bitand(m.flags,1),1,'YES','NO'),
       m.drop_segments
from sys.mon_mods_all$ m, sys.obj$ o, sys.tabsubpart$ tsp, sys.obj$ o2,
     sys.user$ u
where o.obj# = m.obj# and o.owner# = u.user# and
      o.obj# = tsp.obj# and o2.obj# = tsp.pobj#
      and (o.owner# = userenv('SCHEMAID')
           or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in (select kzsrorol from x$kzsro))
           or /* user has system privileges */
             exists (select null from v$enabledprivs
                       where priv_number in (-45 /* LOCK ANY TABLE */,
                                             -47 /* SELECT ANY TABLE */,
                                             -48 /* INSERT ANY TABLE */,
                                             -49 /* UPDATE ANY TABLE */,
                                             -50 /* DELETE ANY TABLE */,
                                             -165/* ANALYZE ANY */))
          )
/
COMMENT ON VIEW SYS.ALL_TAB_MODIFICATIONS IS 'Information regarding modifications to tables'
/
COMMENT ON COLUMN SYS.ALL_TAB_MODIFICATIONS.TABLE_OWNER IS 'Owner of modified table'
/
COMMENT ON COLUMN SYS.ALL_TAB_MODIFICATIONS.TABLE_NAME IS 'Modified table'
/
COMMENT ON COLUMN SYS.ALL_TAB_MODIFICATIONS.PARTITION_NAME IS 'Modified partition'
/
COMMENT ON COLUMN SYS.ALL_TAB_MODIFICATIONS.SUBPARTITION_NAME IS 'Modified subpartition'
/
COMMENT ON COLUMN SYS.ALL_TAB_MODIFICATIONS.INSERTS IS 'Approximate number of rows inserted since last analyze'
/
COMMENT ON COLUMN SYS.ALL_TAB_MODIFICATIONS.UPDATES IS 'Approximate number of rows updated since last analyze'
/
COMMENT ON COLUMN SYS.ALL_TAB_MODIFICATIONS.DELETES IS 'Approximate number of rows deleted since last analyze'
/
COMMENT ON COLUMN SYS.ALL_TAB_MODIFICATIONS.TIMESTAMP IS 'Timestamp of last time this row was modified'
/
COMMENT ON COLUMN SYS.ALL_TAB_MODIFICATIONS.TRUNCATED IS 'Was this object truncated since the last analyze?'
/
COMMENT ON COLUMN SYS.ALL_TAB_MODIFICATIONS.DROP_SEGMENTS IS 'Number of (sub)partition segment dropped since the last analyze?'
/
