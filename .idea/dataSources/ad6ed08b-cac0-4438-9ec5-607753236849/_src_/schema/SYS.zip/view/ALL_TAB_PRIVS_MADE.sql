CREATE VIEW ALL_TAB_PRIVS_MADE AS select ue.name, u.name, o.name, ur.name, tpm.name,
       decode(mod(oa.option$,2), 1, 'YES', 'NO'),
       decode(bitand(oa.option$,2), 2, 'YES', 'NO')
from sys.objauth$ oa, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.user$ ur,
     sys.user$ ue, table_privilege_map tpm
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and u.user# = o.owner#
  and oa.col# is null
  and oa.privilege# = tpm.privilege
  and userenv('SCHEMAID') in (o.owner#, oa.grantor#)
/
COMMENT ON VIEW SYS.ALL_TAB_PRIVS_MADE IS 'User''s grants and grants on user''s objects'
/
COMMENT ON COLUMN SYS.ALL_TAB_PRIVS_MADE.GRANTEE IS 'Name of the user to whom access was granted'
/
COMMENT ON COLUMN SYS.ALL_TAB_PRIVS_MADE.OWNER IS 'Owner of the object'
/
COMMENT ON COLUMN SYS.ALL_TAB_PRIVS_MADE.TABLE_NAME IS 'Name of the object'
/
COMMENT ON COLUMN SYS.ALL_TAB_PRIVS_MADE.GRANTOR IS 'Name of the user who performed the grant'
/
COMMENT ON COLUMN SYS.ALL_TAB_PRIVS_MADE.PRIVILEGE IS 'Table Privilege'
/
COMMENT ON COLUMN SYS.ALL_TAB_PRIVS_MADE.GRANTABLE IS 'Privilege is grantable'
/
COMMENT ON COLUMN SYS.ALL_TAB_PRIVS_MADE.HIERARCHY IS 'Privilege is with hierarchy option'
/
