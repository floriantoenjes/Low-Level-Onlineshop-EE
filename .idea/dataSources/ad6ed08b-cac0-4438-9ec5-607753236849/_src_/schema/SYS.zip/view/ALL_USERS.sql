CREATE VIEW ALL_USERS AS select u.name, u.user#, u.ctime
from sys.user$ u, sys.ts$ dts, sys.ts$ tts
where u.datats# = dts.ts#
  and u.tempts# = tts.ts#
  and u.type# = 1
/
COMMENT ON VIEW SYS.ALL_USERS IS 'Information about all users of the database'
/
COMMENT ON COLUMN SYS.ALL_USERS.USERNAME IS 'Name of the user'
/
COMMENT ON COLUMN SYS.ALL_USERS.USER_ID IS 'ID number of the user'
/
COMMENT ON COLUMN SYS.ALL_USERS.CREATED IS 'User creation date'
/
