CREATE VIEW DATABASE_COMPATIBLE_LEVEL AS select value,description
from v$parameter
where name = 'compatible'
/
COMMENT ON VIEW SYS.DATABASE_COMPATIBLE_LEVEL IS 'Database compatible parameter set via init.ora'
/
COMMENT ON COLUMN SYS.DATABASE_COMPATIBLE_LEVEL.VALUE IS 'Parameter value'
/
COMMENT ON COLUMN SYS.DATABASE_COMPATIBLE_LEVEL.DESCRIPTION IS 'Description of value'
/
