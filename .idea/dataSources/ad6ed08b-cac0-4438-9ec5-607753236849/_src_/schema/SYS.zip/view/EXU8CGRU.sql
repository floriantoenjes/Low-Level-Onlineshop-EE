CREATE VIEW EXU8CGRU AS SELECT  "OBJID","GRANTOR","GRANTORID","GRANTEE","CREATORID","CNAME","PRIV","SEQUENCE","WGO"
        FROM    sys.exu8cgr
        WHERE   grantorid = UID AND
                creatorid = UID
/
