CREATE VIEW EXU8CMTU AS SELECT  "USERID","OBJID","COLNO","COLNAME","CMNT"
        FROM    sys.exu8cmt
        WHERE   userid = UID
/
