CREATE VIEW EXU8GRNU AS SELECT  "OBJID","GRANTOR","GRANTORID","GRANTEE","PRIV","WHO","WGO","CREATORID","SEQUENCE","ISDIR","TYPE"
        FROM    sys.exu8grn
        WHERE   grantorid = UID AND
                creatorid = UID
/
