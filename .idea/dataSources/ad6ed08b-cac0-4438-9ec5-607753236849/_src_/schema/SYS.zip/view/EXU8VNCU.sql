CREATE VIEW EXU8VNCU AS SELECT  "VOBJID","VNAME","VTEXT","VOWNER","VOWNERID","VAUDIT","VCOMMENT","VCNAME","PROPERTY","DEFER","FLAGS","OIDLEN","OIDCLAUSE","TYPEOWNER","TYPENAME","VLEN"
        FROM    sys.exu8vinfu vf$
        WHERE   NOT EXISTS (
                    SELECT  0
                    FROM    sys.exu8vdptu vd$
                    WHERE   vd$.parent = vf$.vobjid)
/
