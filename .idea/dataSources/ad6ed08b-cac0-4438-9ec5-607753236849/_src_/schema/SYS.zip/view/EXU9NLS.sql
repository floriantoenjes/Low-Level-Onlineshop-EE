CREATE VIEW EXU9NLS AS SELECT  name, value$
        FROM    sys.props$
        WHERE   name IN ('NLS_CHARACTERSET',
                         'NLS_NCHAR_CHARACTERSET',
                         'NLS_LENGTH_SEMANTICS')
/
