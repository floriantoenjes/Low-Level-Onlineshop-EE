CREATE VIEW GV_$ACTIVE_INSTANCES AS select "INST_ID","INST_NUMBER","INST_NAME" from gv$active_instances
/
