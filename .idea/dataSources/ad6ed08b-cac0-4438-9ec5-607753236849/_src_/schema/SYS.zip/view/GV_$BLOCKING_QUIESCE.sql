CREATE VIEW GV_$BLOCKING_QUIESCE AS select "INST_ID","SID" from gv$blocking_quiesce
/
