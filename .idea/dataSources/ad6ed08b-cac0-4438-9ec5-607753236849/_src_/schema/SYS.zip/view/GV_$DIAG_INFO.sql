CREATE VIEW GV_$DIAG_INFO AS select "INST_ID","NAME","VALUE" from gv$diag_info
/
