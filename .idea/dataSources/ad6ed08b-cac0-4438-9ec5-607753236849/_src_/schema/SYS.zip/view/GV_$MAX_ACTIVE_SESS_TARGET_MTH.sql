CREATE VIEW GV_$MAX_ACTIVE_SESS_TARGET_MTH AS select "INST_ID","NAME" from gv$max_active_sess_target_mth
/
