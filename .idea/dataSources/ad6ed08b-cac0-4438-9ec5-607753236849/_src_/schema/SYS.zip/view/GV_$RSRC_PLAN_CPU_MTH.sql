CREATE VIEW GV_$RSRC_PLAN_CPU_MTH AS select "INST_ID","NAME" from gv$rsrc_plan_cpu_mth
/
