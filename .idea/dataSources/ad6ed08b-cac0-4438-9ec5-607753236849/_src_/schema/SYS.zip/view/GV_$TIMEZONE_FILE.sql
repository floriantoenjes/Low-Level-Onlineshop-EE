CREATE VIEW GV_$TIMEZONE_FILE AS select "FILENAME","VERSION" from gv$timezone_file
/
