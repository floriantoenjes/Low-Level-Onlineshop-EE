CREATE VIEW IMP9USR AS SELECT  u.name, u.user#
        FROM    sys.user$ u
        WHERE   u.user# = UID
/
