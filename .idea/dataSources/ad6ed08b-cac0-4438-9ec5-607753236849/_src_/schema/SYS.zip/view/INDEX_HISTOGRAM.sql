CREATE VIEW INDEX_HISTOGRAM AS select hist.indx * power(2, stats.kdxstscl-4)  repeat_count,
        hist.kdxhsval                           keys_with_repeat_count
        from  x$kdxst stats, x$kdxhs hist
/
COMMENT ON VIEW SYS.INDEX_HISTOGRAM IS 'statistics on keys with repeat count'
/
COMMENT ON COLUMN SYS.INDEX_HISTOGRAM.REPEAT_COUNT IS 'number of times that a key is repeated'
/
COMMENT ON COLUMN SYS.INDEX_HISTOGRAM.KEYS_WITH_REPEAT_COUNT IS 'number of keys that are repeated REPEAT_COUNT times'
/
