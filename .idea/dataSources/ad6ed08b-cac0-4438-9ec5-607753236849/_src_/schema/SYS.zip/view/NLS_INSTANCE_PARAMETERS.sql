CREATE VIEW NLS_INSTANCE_PARAMETERS AS select substr(upper(name), 1, 30),
       substr(value, 1, 40)
from v$system_parameter
where name like 'nls%'
/
COMMENT ON VIEW SYS.NLS_INSTANCE_PARAMETERS IS 'NLS parameters of the instance'
/
COMMENT ON COLUMN SYS.NLS_INSTANCE_PARAMETERS.PARAMETER IS 'Parameter name'
/
COMMENT ON COLUMN SYS.NLS_INSTANCE_PARAMETERS.VALUE IS 'Parameter value'
/
