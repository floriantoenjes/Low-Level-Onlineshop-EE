CREATE VIEW NLS_SESSION_PARAMETERS AS select substr(parameter, 1, 30),
       substr(value, 1, 40)
from v$nls_parameters
where parameter != 'NLS_CHARACTERSET' and
 parameter != 'NLS_NCHAR_CHARACTERSET'
/
COMMENT ON VIEW SYS.NLS_SESSION_PARAMETERS IS 'NLS parameters of the user session'
/
COMMENT ON COLUMN SYS.NLS_SESSION_PARAMETERS.PARAMETER IS 'Parameter name'
/
COMMENT ON COLUMN SYS.NLS_SESSION_PARAMETERS.VALUE IS 'Parameter value'
/
