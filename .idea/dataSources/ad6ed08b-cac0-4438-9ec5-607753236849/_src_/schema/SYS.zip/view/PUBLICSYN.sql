CREATE VIEW PUBLICSYN AS select sname, creator, tname, database, tabtype
  from  synonyms
  where syntype = 'PUBLIC'
/
