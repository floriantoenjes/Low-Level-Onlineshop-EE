CREATE VIEW RESOURCE_COST AS select m.name,c.cost
  from sys.resource_cost$ c, sys.resource_map m where
  c.resource# = m.resource#
  and m.type# = 0
  and c.resource# in (2, 4, 7, 8)
/
COMMENT ON VIEW SYS.RESOURCE_COST IS 'Cost for each resource'
/
COMMENT ON COLUMN SYS.RESOURCE_COST.RESOURCE_NAME IS 'Name of resource'
/
COMMENT ON COLUMN SYS.RESOURCE_COST.UNIT_COST IS 'Cost for resource'
/
