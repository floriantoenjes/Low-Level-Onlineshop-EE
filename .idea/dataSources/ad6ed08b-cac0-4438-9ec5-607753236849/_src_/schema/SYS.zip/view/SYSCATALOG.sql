CREATE VIEW SYSCATALOG AS select tname, creator, tabletype, remarks
  from syscatalog_
/
