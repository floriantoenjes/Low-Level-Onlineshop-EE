CREATE VIEW USER_ALL_TABLES AS select TABLE_NAME, TABLESPACE_NAME, CLUSTER_NAME, IOT_NAME, STATUS,
     PCT_FREE, PCT_USED,
     INI_TRANS, MAX_TRANS,
     INITIAL_EXTENT, NEXT_EXTENT,
     MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE,
     FREELISTS, FREELIST_GROUPS, LOGGING,
     BACKED_UP, NUM_ROWS, BLOCKS, EMPTY_BLOCKS,
     AVG_SPACE, CHAIN_CNT, AVG_ROW_LEN,
     AVG_SPACE_FREELIST_BLOCKS, NUM_FREELIST_BLOCKS,
     DEGREE, INSTANCES, CACHE, TABLE_LOCK,
     SAMPLE_SIZE, LAST_ANALYZED, PARTITIONED,
     IOT_TYPE,
     NULL, NULL, NULL, TEMPORARY, SECONDARY, NESTED,
     BUFFER_POOL, FLASH_CACHE,
     CELL_FLASH_CACHE, ROW_MOVEMENT,
     GLOBAL_STATS, USER_STATS, DURATION, SKIP_CORRUPT, MONITORING,
     CLUSTER_OWNER, DEPENDENCIES, COMPRESSION, COMPRESS_FOR, DROPPED,
     SEGMENT_CREATED
from user_tables
union all
select TABLE_NAME, TABLESPACE_NAME, CLUSTER_NAME, IOT_NAME, STATUS,
     PCT_FREE, PCT_USED,
     INI_TRANS, MAX_TRANS,
     INITIAL_EXTENT, NEXT_EXTENT,
     MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE,
     FREELISTS, FREELIST_GROUPS, LOGGING,
     BACKED_UP, NUM_ROWS, BLOCKS, EMPTY_BLOCKS,
     AVG_SPACE, CHAIN_CNT, AVG_ROW_LEN,
     AVG_SPACE_FREELIST_BLOCKS, NUM_FREELIST_BLOCKS,
     DEGREE, INSTANCES, CACHE, TABLE_LOCK,
     SAMPLE_SIZE, LAST_ANALYZED, PARTITIONED,
     IOT_TYPE, OBJECT_ID_TYPE,
     TABLE_TYPE_OWNER, TABLE_TYPE, TEMPORARY, SECONDARY, NESTED,
     BUFFER_POOL, FLASH_CACHE,
     CELL_FLASH_CACHE, ROW_MOVEMENT,
     GLOBAL_STATS, USER_STATS, DURATION, SKIP_CORRUPT, MONITORING,
     CLUSTER_OWNER, DEPENDENCIES, COMPRESSION, COMPRESS_FOR, DROPPED,
     SEGMENT_CREATED
from user_object_tables
/
COMMENT ON VIEW SYS.USER_ALL_TABLES IS 'Description of all object and relational tables owned by the user''s'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.TABLE_NAME IS 'Name of the table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.TABLESPACE_NAME IS 'Name of the tablespace containing the table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.CLUSTER_NAME IS 'Name of the cluster, if any, to which the table belongs'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.IOT_NAME IS 'Name of the index-only table, if any, to which the overflow or mapping table entry belongs'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.STATUS IS 'Status of the table will be UNUSABLE if a previous DROP TABLE operation failed,
VALID otherwise'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.PCT_FREE IS 'Minimum percentage of free space in a block'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.PCT_USED IS 'Minimum percentage of used space in a block'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.INI_TRANS IS 'Initial number of transactions'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.MAX_TRANS IS 'Maximum number of transactions'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.INITIAL_EXTENT IS 'Size of the initial extent in bytes'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.NEXT_EXTENT IS 'Size of secondary extents in bytes'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.MIN_EXTENTS IS 'Minimum number of extents allowed in the segment'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.MAX_EXTENTS IS 'Maximum number of extents allowed in the segment'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.PCT_INCREASE IS 'Percentage increase in extent size'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.FREELISTS IS 'Number of process freelists allocated in this segment'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.FREELIST_GROUPS IS 'Number of freelist groups allocated in this segment'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.LOGGING IS 'Logging attribute'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.BACKED_UP IS 'Has table been backed up since last modification?'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.NUM_ROWS IS 'The number of rows in the table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.BLOCKS IS 'The number of used blocks in the table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.EMPTY_BLOCKS IS 'The number of empty (never used) blocks in the table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.AVG_SPACE IS 'The average available free space in the table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.CHAIN_CNT IS 'The number of chained rows in the table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.AVG_ROW_LEN IS 'The average row length, including row overhead'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.AVG_SPACE_FREELIST_BLOCKS IS 'The average freespace of all blocks on a freelist'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.NUM_FREELIST_BLOCKS IS 'The number of blocks on the freelist'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.DEGREE IS 'The number of threads per instance for scanning the table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.INSTANCES IS 'The number of instances across which the table is to be scanned'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.CACHE IS 'Whether the table is to be cached in the buffer cache'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.TABLE_LOCK IS 'Whether table locking is enabled or disabled'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.SAMPLE_SIZE IS 'The sample size used in analyzing this table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.LAST_ANALYZED IS 'The date of the most recent time this table was analyzed'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.PARTITIONED IS 'Is this table partitioned? YES or NO'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.IOT_TYPE IS 'If index-only table, then IOT_TYPE is IOT or IOT_OVERFLOW or IOT_MAPPING else NULL'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.OBJECT_ID_TYPE IS 'If user-defined OID, then USER-DEFINED, else if system generated OID, then SYST
EM GENERATED'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.TABLE_TYPE_OWNER IS 'Owner of the type of the table if the table is an object table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.TABLE_TYPE IS 'Type of the table if the table is an object table'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.TEMPORARY IS 'Can the current session only see data that it place in this object itself?'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.SECONDARY IS 'Is this table object created as part of icreate for domain indexes?'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.NESTED IS 'Is the table a nested table?'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.BUFFER_POOL IS 'The default buffer pool to be used for table blocks'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.FLASH_CACHE IS 'The default flash cache hint to be used for table blocks'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.CELL_FLASH_CACHE IS 'The default cell flash cache hint to be used for table blocks'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.ROW_MOVEMENT IS 'Whether partitioned row movement is enabled or disabled'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.GLOBAL_STATS IS 'Are the statistics calculated without merging underlying partitions?'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.USER_STATS IS 'Were the statistics entered directly by the user?'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.DURATION IS 'If temporary table, then duration is sys$session or sys$transaction else NULL'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.SKIP_CORRUPT IS 'Whether skip corrupt blocks is enabled or disabled'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.MONITORING IS 'Should we keep track of the amount of modification?'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.CLUSTER_OWNER IS 'Owner of the cluster, if any, to which the table belongs'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.DEPENDENCIES IS 'Should we keep track of row level dependencies?'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.COMPRESSION IS 'Whether table compression is enabled or not'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.COMPRESS_FOR IS 'Compress what kind of operations'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.DROPPED IS 'Whether table is dropped and is in Recycle Bin'
/
COMMENT ON COLUMN SYS.USER_ALL_TABLES.SEGMENT_CREATED IS 'Whether the table segment is created or not'
/
