CREATE VIEW USER_DIM_ATTRIBUTES AS select u.name, o.name, da.attname, dl.levelname, c.name, 'N'
from sys.dimattr$ da, sys.obj$ o, sys.user$ u, sys.dimlevel$ dl, sys.col$ c
where da.dimobj# = o.obj#
  and o.owner# = u.user#
  and da.dimobj# = dl.dimobj#
  and da.levelid# = dl.levelid#
  and da.detailobj# = c.obj#
  and da.col# = c.intcol#
  and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_DIM_ATTRIBUTES IS 'Representation of the relationship between a dimension level and
 a functionally dependent column'
/
COMMENT ON COLUMN SYS.USER_DIM_ATTRIBUTES.OWNER IS 'Owner of the dimentsion'
/
COMMENT ON COLUMN SYS.USER_DIM_ATTRIBUTES.DIMENSION_NAME IS 'Name of the dimension'
/
COMMENT ON COLUMN SYS.USER_DIM_ATTRIBUTES.ATTRIBUTE_NAME IS 'Name of the attribute'
/
COMMENT ON COLUMN SYS.USER_DIM_ATTRIBUTES.LEVEL_NAME IS 'Name of the hierarchy level'
/
COMMENT ON COLUMN SYS.USER_DIM_ATTRIBUTES.COLUMN_NAME IS 'Name of the dependent column'
/
COMMENT ON COLUMN SYS.USER_DIM_ATTRIBUTES.INFERRED IS 'Whether this attribute is inferred from a JOIN KEY specification'
/
