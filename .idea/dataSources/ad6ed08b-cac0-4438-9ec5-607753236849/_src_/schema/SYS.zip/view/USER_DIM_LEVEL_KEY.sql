CREATE VIEW USER_DIM_LEVEL_KEY AS select u.name, o.name, dl.levelname, dlk.keypos#, c.name
from sys.dimlevelkey$ dlk, sys.obj$ o, sys.user$ u, sys.dimlevel$ dl,
     sys.col$ c
where dlk.dimobj# = o.obj#
  and o.owner# = u.user#
  and dlk.dimobj# = dl.dimobj#
  and dlk.levelid# = dl.levelid#
  and dlk.detailobj# = c.obj#
  and dlk.col# = c.intcol#
  and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_DIM_LEVEL_KEY IS 'Representations of columns of a dimension level'
/
COMMENT ON COLUMN SYS.USER_DIM_LEVEL_KEY.OWNER IS 'Owner of the dimension'
/
COMMENT ON COLUMN SYS.USER_DIM_LEVEL_KEY.DIMENSION_NAME IS 'Name of the dimension'
/
COMMENT ON COLUMN SYS.USER_DIM_LEVEL_KEY.LEVEL_NAME IS 'Name of the hierarchy level'
/
COMMENT ON COLUMN SYS.USER_DIM_LEVEL_KEY.KEY_POSITION IS 'Ordinal position of the key column within the level'
/
COMMENT ON COLUMN SYS.USER_DIM_LEVEL_KEY.COLUMN_NAME IS 'Name of the key column'
/
