CREATE VIEW USER_IND_EXPRESSIONS AS select idx.name, base.name, c.default$, ic.pos#
from sys.col$ c, sys.obj$ idx, sys.obj$ base, sys.icol$ ic, sys.ind$ i
where bitand(ic.spare1,1) = 1       /* an expression */
  and (bitand(i.property,1024) = 0) /* not bmji */
  and c.obj# = base.obj#
  and ic.bo# = base.obj#
  and ic.intcol# = c.intcol#
  and base.owner# = userenv('SCHEMAID')
  and base.namespace in (1, 5)
  and ic.obj# = idx.obj#
  and idx.obj# = i.obj#
  and i.type# in (1, 2, 3, 4, 6, 7, 9)
union all
select idx.name, base.name, c.default$, ic.pos#
from sys.col$ c, sys.obj$ idx, sys.obj$ base, sys.icol$ ic, sys.ind$ i
where bitand(ic.spare1,1) = 1       /* an expression */
  and (bitand(i.property,1024) = 0) /* not bmji */
  and c.obj# = base.obj#
  and i.bo# = base.obj#
  and base.owner# != userenv('SCHEMAID')
  and ic.intcol# = c.intcol#
  and idx.owner# = userenv('SCHEMAID')
  and idx.namespace = 4 /* index namespace */
  and ic.obj# = idx.obj#
  and idx.obj# = i.obj#
  and i.type# in (1, 2, 3, 4, 6, 7, 9)
/
COMMENT ON VIEW SYS.USER_IND_EXPRESSIONS IS 'Functional index expressions in user''s indexes and indexes on user''s tables'
/
COMMENT ON COLUMN SYS.USER_IND_EXPRESSIONS.INDEX_NAME IS 'Index name'
/
COMMENT ON COLUMN SYS.USER_IND_EXPRESSIONS.TABLE_NAME IS 'Table or cluster name'
/
COMMENT ON COLUMN SYS.USER_IND_EXPRESSIONS.COLUMN_EXPRESSION IS 'Functional index expression defining the column'
/
COMMENT ON COLUMN SYS.USER_IND_EXPRESSIONS.COLUMN_POSITION IS 'Position of column or attribute within index'
/
