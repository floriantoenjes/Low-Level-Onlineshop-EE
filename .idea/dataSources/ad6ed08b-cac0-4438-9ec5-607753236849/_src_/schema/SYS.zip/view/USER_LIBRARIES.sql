CREATE VIEW USER_LIBRARIES AS select o.name,
       l.filespec,
       decode(bitand(l.property, 1), 0, 'Y', 1, 'N', NULL),
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID')
from sys."_CURRENT_EDITION_OBJ" o, sys.library$ l
where o.owner# = userenv('SCHEMAID')
  and o.obj# = l.obj#
/
COMMENT ON VIEW SYS.USER_LIBRARIES IS 'Description of the user''s own libraries'
/
COMMENT ON COLUMN SYS.USER_LIBRARIES.LIBRARY_NAME IS 'Name of the library'
/
COMMENT ON COLUMN SYS.USER_LIBRARIES.FILE_SPEC IS 'Operating system file specification of the library'
/
COMMENT ON COLUMN SYS.USER_LIBRARIES.DYNAMIC IS 'Is the library dynamically loadable'
/
COMMENT ON COLUMN SYS.USER_LIBRARIES.STATUS IS 'Status of the library'
/
