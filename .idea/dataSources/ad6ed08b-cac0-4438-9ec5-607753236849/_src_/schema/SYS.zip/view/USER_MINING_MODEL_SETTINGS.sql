CREATE VIEW USER_MINING_MODEL_SETTINGS AS select o.name, s.name, s.value,
       decode(bitand(s.properties,1),1,'INPUT','DEFAULT')
from sys.modelset$ s, sys.obj$ o
where s.mod#=o.obj#
  and o.owner#=userenv('SCHEMAID')
  and bitand(s.properties,2) != 2
/
COMMENT ON VIEW SYS.USER_MINING_MODEL_SETTINGS IS 'Description of the user''s own model settings'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_SETTINGS.MODEL_NAME IS 'Name of the model to which the setting belongs'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_SETTINGS.SETTING_NAME IS 'Name of the setting'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_SETTINGS.SETTING_VALUE IS 'Value of the setting'
/
COMMENT ON COLUMN SYS.USER_MINING_MODEL_SETTINGS.SETTING_TYPE IS 'Type of the setting'
/
