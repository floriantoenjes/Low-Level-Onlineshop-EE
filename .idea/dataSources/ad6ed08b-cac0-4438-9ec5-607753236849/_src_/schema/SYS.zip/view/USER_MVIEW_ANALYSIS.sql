CREATE VIEW USER_MVIEW_ANALYSIS AS select u.name, o.name, u.name, s.containernam,
       s.lastrefreshscn, s.lastrefreshdate,
       decode (s.refreshmode, 0, 'NEVER', 1, 'FORCE', 2, 'FAST', 3,'COMPLETE'),
       decode(bitand(s.pflags, 25165824), 25165824, 'N', 'Y'),
       s.fullrefreshtim, s.increfreshtim,
       decode(bitand(s.pflags, 48), 0, 'N', 'Y'),
       decode(bitand(s.mflags, 64), 0, 'N', 'Y'), /* QSMQSUM_UNUSABLE */
       decode(bitand(s.pflags, 1294319), 0, 'Y', 'N'),
       decode(bitand((select n.flag2 from sys.snap$ n
                      where n.vname=s.containernam and n.sowner=u.name), 67108864),
                     67108864,  /* primary CUBE mv? */
                     decode(bitand((select n2.flag from sys.snap$ n2
                            where n2.parent_sowner=u.name and n2.parent_vname=s.containernam), 256),
                            256, 'N', 'Y'), /* Its child mv's properties determin INC_REFRESHABLE */
                     decode(bitand(s.pflags, 236879743), 0, 'Y', 'N')),
       decode(bitand(s.mflags, 1), 0, 'N', 'Y'), /* QSMQSUM_KNOWNSTL */
       decode(o.status, 5, 'Y', 'N'),
       decode(bitand(s.mflags, 4), 0, 'Y', 'N'), /* QSMQSUM_DISABLED */
       s.sumtextlen,s.sumtext,
       s.metaversion/* Metadata revision number */
from sys.user$ u, sys.sum$ s, sys.obj$ o
where o.owner# = u.user#
  and o.obj# = s.obj#
  and o.owner# = userenv('SCHEMAID')
  and bitand(s.xpflags, 8388608) = 0 /* NOT REWRITE EQUIVALENCE SUMMARY */
/
COMMENT ON VIEW SYS.USER_MVIEW_ANALYSIS IS 'Description of the materialized views created by the user'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.OWNER IS 'Owner of the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.MVIEW_NAME IS 'Name of the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.MVIEW_TABLE_OWNER IS 'Owner of the container table'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.CONTAINER_NAME IS 'Name of the container table for this materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.LAST_REFRESH_SCN IS 'The SCN of the last transaction to refresh the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.LAST_REFRESH_DATE IS 'The date of the last refresh of the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.REFRESH_METHOD IS 'User declared method of refresh for the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.FULLREFRESHTIM IS 'The time that it took to fully refresh the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.INCREFRESHTIM IS 'The time that it took to incrementally refresh the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.CONTAINS_VIEWS IS 'This materialized view contains views in the FROM clause'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.UNUSABLE IS 'This materialized view is unusable, the build was deferred'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.RESTRICTED_SYNTAX IS 'This materialized view contains restrictive syntax'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.INC_REFRESHABLE IS 'This materialized view is not restricted from being incrementally refreshed'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.KNOWN_STALE IS 'This materialized view is directly stale'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.INVALID IS 'Invalidity of the materialized view, Y = INVALID, N = VALID'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.REWRITE_ENABLED IS 'This materialized view is enabled for query rewrite'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.QUERY_LEN IS 'The length (in bytes) of the query field'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.QUERY IS 'SELECT expression of the materialized view definition'
/
COMMENT ON COLUMN SYS.USER_MVIEW_ANALYSIS.REVISION IS 'Reserved for internal use'
/
