CREATE VIEW USER_MVIEW_COMMENTS AS select o.name, c.comment$
from sys.obj$ o, sys.com$ c, sys.tab$ t
  where o.owner# = userenv('SCHEMAID')
  and o.type# = 2
  and (bitand(t.property, 67108864) = 67108864)         /*mv container table */
  and o.obj# = c.obj#(+)
  and c.col#(+) is NULL
  and o.obj# = t.obj#
/
COMMENT ON VIEW SYS.USER_MVIEW_COMMENTS IS 'Comments on materialized views owned by the user'
/
COMMENT ON COLUMN SYS.USER_MVIEW_COMMENTS.MVIEW_NAME IS 'Name of the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_COMMENTS.COMMENTS IS 'Comment on the materialized view'
/
