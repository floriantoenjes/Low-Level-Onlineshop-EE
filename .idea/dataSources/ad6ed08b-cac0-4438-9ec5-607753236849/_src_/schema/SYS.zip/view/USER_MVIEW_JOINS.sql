CREATE VIEW USER_MVIEW_JOINS AS select u.name, o.name,
       u1.name, o1.name, c1.name, '=',
       decode(sj.flags, 0, 'I', 1, 'L', 2, 'R'),
       u2.name, o2.name, c2.name
from sys.sumjoin$ sj, sys.obj$ o, sys.user$ u,
     sys.obj$ o1, sys.user$ u1, sys.col$ c1,
     sys.obj$ o2, sys.user$ u2, sys.col$ c2,
     sys.sum$ s
where sj.sumobj# = o.obj#
  AND o.owner# = u.user#
  AND sj.tab1obj# = o1.obj#
  AND o1.owner# = u1.user#
  AND sj.tab1obj# = c1.obj#
  AND sj.tab1col# = c1.intcol#
  AND sj.tab2obj# = o2.obj#
  AND o2.owner# = u2.user#
  AND sj.tab2obj# = c2.obj#
  AND sj.tab2col# = c2.intcol#
  AND o.owner# = userenv('SCHEMAID')
  AND s.obj# = sj.sumobj#
  AND bitand(s.xpflags, 8388608) = 0 /* NOT REWRITE EQUIVALENCE SUMMARY */
/
COMMENT ON VIEW SYS.USER_MVIEW_JOINS IS 'Description of a join between two columns in the
WHERE clause of a materialized view created by the user'
/
COMMENT ON COLUMN SYS.USER_MVIEW_JOINS.OWNER IS 'Owner of the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_JOINS.MVIEW_NAME IS 'Name of the materialized view'
/
COMMENT ON COLUMN SYS.USER_MVIEW_JOINS.DETAILOBJ1_OWNER IS 'Owner of the 1st detail object'
/
COMMENT ON COLUMN SYS.USER_MVIEW_JOINS.DETAILOBJ1_RELATION IS 'Name of the 1st detail object'
/
COMMENT ON COLUMN SYS.USER_MVIEW_JOINS.DETAILOBJ1_COLUMN IS 'Name of the 1st detail object column'
/
COMMENT ON COLUMN SYS.USER_MVIEW_JOINS.OPERATOR IS 'Name of the join operator. Currently only = is defined'
/
COMMENT ON COLUMN SYS.USER_MVIEW_JOINS.DETAILOBJ2_OWNER IS 'Owner of the 2nd detail object'
/
COMMENT ON COLUMN SYS.USER_MVIEW_JOINS.DETAILOBJ2_RELATION IS 'Name of the 2nd detail object'
/
COMMENT ON COLUMN SYS.USER_MVIEW_JOINS.DETAILOBJ2_COLUMN IS 'Name of the 2nd detail object column'
/
