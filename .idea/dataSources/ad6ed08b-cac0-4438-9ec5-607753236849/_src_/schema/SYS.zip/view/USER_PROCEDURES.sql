CREATE VIEW USER_PROCEDURES AS (select o.name, pi.procedurename, o.obj#, pi.procedure#,
decode(pi.overload#, 0, NULL, pi.overload#),
decode(o.type#, 7, 'PROCEDURE',
       8, 'FUNCTION', 9, 'PACKAGE', 11, 'PACKAGE BODY',
       12, 'TRIGGER', 13, 'TYPE', 14, 'TYPE BODY',
       22, 'LIBRARY', 28, 'JAVA SOURCE', 29, 'JAVA CLASS',
       30, 'JAVA RESOURCE', 87, 'ASSEMBLY', 'UNDEFINED'),
decode(bitand(pi.properties,8),8,'YES','NO'),
decode(bitand(pi.properties,16),16,'YES','NO'),
u2.name, o2.name,
decode(bitand(pi.properties,32),32,'YES','NO'),
decode(bitand(pi.properties,512),512,'YES','NO'),
decode(bitand(pi.properties,256),256,'YES','NO'),
decode(bitand(pi.properties,1024),1024,'CURRENT_USER','DEFINER')
from sys."_CURRENT_EDITION_OBJ" o, sys.procedureinfo$ pi,
     sys."_CURRENT_EDITION_OBJ" o2, sys.user$ u2
where o.owner# = userenv('SCHEMAID') and o.obj# = pi.obj#
and (o.type# in (7, 8, 9, 11, 12, 14, 22, 28, 29, 30, 87) or
     (o.type# = 13 and o.subname is null))
and pi.itypeobj# = o2.obj# (+) and o2.owner#  = u2.user# (+))
UNION ALL
(select tabobj.object_name, NULL,
  tabobj.object_id,
  case tabobj.object_type
    when 'TRIGGER' then 1
    else 0
  end,
  NULL, tabobj.object_type, 'NO', 'NO', NULL, NULL, 'NO', 'NO', 'NO',
  case tabobj.object_type
    when 'TRIGGER' then 'DEFINER'
    else
      decode(bitand(pi.properties,1024),
             NULL, NULL,
             1024,'CURRENT_USER','DEFINER')
  end
  from user_objects tabobj, procedureinfo$ pi
  where
    ((tabobj.object_id = pi.obj# (+)) AND
     (tabobj.object_type IN ('TRIGGER', 'PACKAGE')) AND
     ((pi.procedure# is null) OR (pi.procedure# = 1))))
/
COMMENT ON VIEW SYS.USER_PROCEDURES IS 'Description of the user functions/procedures/packages/types/triggers'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.OBJECT_NAME IS 'Name of the object: top level function/procedure/package/type/trigger name'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.PROCEDURE_NAME IS 'Name of the package or type subprogram'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.OBJECT_ID IS 'Object number of the object'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.SUBPROGRAM_ID IS 'Unique sub-program identifier'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.OVERLOAD IS 'Overload unique identifier'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.OBJECT_TYPE IS 'The typename of the object'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.AGGREGATE IS 'Is it an aggregate function ?'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.PIPELINED IS 'Is it a pipelined table function ?'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.IMPLTYPEOWNER IS 'Name of the owner of the implementation type (if any)'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.IMPLTYPENAME IS 'Name of the implementation type (if any)'
/
COMMENT ON COLUMN SYS.USER_PROCEDURES.PARALLEL IS 'Is the procedure parallel enabled ?'
/
