CREATE VIEW USER_PUBLISHED_COLUMNS AS SELECT
   s.change_set_name, s.obj#, s.source_schema_name, s.source_table_name,
   c.column_name, c.data_type, c.data_length, c.data_precision, c.data_scale,
   c.nullable
  FROM sys.cdc_change_tables$ s, all_tables t, all_tab_columns c, sys.user$ u
  WHERE s.change_table_schema=t.owner AND
        s.change_table_name=t.table_name AND
        c.owner=s.change_table_schema AND
        c.table_name=s.change_table_name AND
        c.column_name NOT IN ('OPERATION$','CSCN$','DDLDESC$','DDLPDOBJN$',
           'DDLOPER$','RSID$','SOURCE_COLMAP$','TARGET_COLMAP$',
           'COMMIT_TIMESTAMP$','TIMESTAMP$','USERNAME$','ROW_ID$',
           'XIDUSN$','XIDSLT$','XIDSEQ$','SYS_NC_OID$') AND
        s.change_table_schema = u.name AND
        u.user# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_PUBLISHED_COLUMNS IS 'Source columns available for Change Data Capture'
/
COMMENT ON COLUMN SYS.USER_PUBLISHED_COLUMNS.CHANGE_SET_NAME IS 'Change set in which source column is published'
/
COMMENT ON COLUMN SYS.USER_PUBLISHED_COLUMNS.PUB_ID IS 'Publication ID in which source column is published'
/
COMMENT ON COLUMN SYS.USER_PUBLISHED_COLUMNS.SOURCE_SCHEMA_NAME IS 'Source schema name of published column'
/
COMMENT ON COLUMN SYS.USER_PUBLISHED_COLUMNS.SOURCE_TABLE_NAME IS 'Source table name of published column'
/
COMMENT ON COLUMN SYS.USER_PUBLISHED_COLUMNS.COLUMN_NAME IS 'Column name of published column'
/
COMMENT ON COLUMN SYS.USER_PUBLISHED_COLUMNS.DATA_TYPE IS 'Column datatype'
/
COMMENT ON COLUMN SYS.USER_PUBLISHED_COLUMNS.DATA_LENGTH IS 'Column length'
/
COMMENT ON COLUMN SYS.USER_PUBLISHED_COLUMNS.DATA_PRECISION IS 'Column precision'
/
COMMENT ON COLUMN SYS.USER_PUBLISHED_COLUMNS.DATA_SCALE IS 'Column scale'
/
COMMENT ON COLUMN SYS.USER_PUBLISHED_COLUMNS.NULLABLE IS 'Whether column is nullable'
/
