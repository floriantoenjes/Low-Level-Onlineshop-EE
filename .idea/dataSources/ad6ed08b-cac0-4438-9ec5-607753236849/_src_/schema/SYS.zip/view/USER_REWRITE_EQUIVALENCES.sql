CREATE VIEW USER_REWRITE_EQUIVALENCES AS select m."OWNER",m."NAME",m."SOURCE_STMT",m."DESTINATION_STMT",m."REWRITE_MODE" from dba_rewrite_equivalences m, sys.user$ u
where u.name = m.owner
  and u.user# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_REWRITE_EQUIVALENCES IS 'Description of all rewrite equivalence owned by the user'
/
COMMENT ON COLUMN SYS.USER_REWRITE_EQUIVALENCES.OWNER IS 'Owner of the rewrite equivalence'
/
COMMENT ON COLUMN SYS.USER_REWRITE_EQUIVALENCES.NAME IS 'Name of the rewrite equivalence'
/
COMMENT ON COLUMN SYS.USER_REWRITE_EQUIVALENCES.SOURCE_STMT IS 'Source statement of the rewrite equivalence'
/
COMMENT ON COLUMN SYS.USER_REWRITE_EQUIVALENCES.DESTINATION_STMT IS 'Destination of the rewrite equivalence'
/
COMMENT ON COLUMN SYS.USER_REWRITE_EQUIVALENCES.REWRITE_MODE IS 'Rewrite mode of the rewrite equivalence'
/
