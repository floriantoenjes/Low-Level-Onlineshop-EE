CREATE VIEW USER_SUBSCRIBED_COLUMNS AS SELECT
   s.handle, t.source_schema_name, t.source_table_name, s.column_name,
   u.subscription_name, z.source_database
  FROM sys.cdc_subscribed_columns$ s, sys.cdc_change_tables$ t,
       sys.cdc_subscribers$ u, sys.user$ su, sys.cdc_change_sets$ x,
       sys.cdc_change_sources$ z
  WHERE s.change_table_obj#=t.obj# AND
        s.handle=u.handle AND
        u.username = su.name AND
        su.user#   = userenv('SCHEMAID') AND
        t.change_set_name=x.set_name AND
        x.change_source_name = z.source_name
/
COMMENT ON VIEW SYS.USER_SUBSCRIBED_COLUMNS IS 'Change Data Capture subscribed columns'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_COLUMNS.HANDLE IS 'Unique identifier of the subscription'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_COLUMNS.SOURCE_SCHEMA_NAME IS 'Source schema name of the subscribed column'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_COLUMNS.SOURCE_TABLE_NAME IS 'Source table name of the subscribed column'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_COLUMNS.COLUMN_NAME IS 'Name of the subscribed column'
/
COMMENT ON COLUMN SYS.USER_SUBSCRIBED_COLUMNS.SUBSCRIPTION_NAME IS 'Name of the subscription'
/
