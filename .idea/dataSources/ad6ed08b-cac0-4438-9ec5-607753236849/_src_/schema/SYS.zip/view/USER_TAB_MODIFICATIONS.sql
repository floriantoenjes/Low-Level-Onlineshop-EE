CREATE VIEW USER_TAB_MODIFICATIONS AS select o.name, null, null,
       m.inserts, m.updates, m.deletes, m.timestamp,
       decode(bitand(m.flags,1),1,'YES','NO'),
       m.drop_segments
from sys.mon_mods_all$ m, sys.obj$ o, sys.tab$ t
where o.owner# = userenv('SCHEMAID') and o.obj# = m.obj# and o.obj# = t.obj#
union all
  select o.name, o.subname, null,
       m.inserts, m.updates, m.deletes, m.timestamp,
       decode(bitand(m.flags,1),1,'YES','NO'),
       m.drop_segments
  from sys.mon_mods_all$ m, sys.obj$ o
  where o.owner# = userenv('SCHEMAID') and o.obj# = m.obj# and o.type#=19
union all
select o.name, o2.subname, o.subname,
       m.inserts, m.updates, m.deletes, m.timestamp,
       decode(bitand(m.flags,1),1,'YES','NO'),
       m.drop_segments
from sys.mon_mods_all$ m, sys.obj$ o, sys.tabsubpart$ tsp, sys.obj$ o2
where o.owner# = userenv('SCHEMAID') and o.obj# = m.obj# and
      o.obj# = tsp.obj# and o2.obj# = tsp.pobj#
/
COMMENT ON VIEW SYS.USER_TAB_MODIFICATIONS IS 'Information regarding modifications to tables'
/
COMMENT ON COLUMN SYS.USER_TAB_MODIFICATIONS.TABLE_NAME IS 'Modified table'
/
COMMENT ON COLUMN SYS.USER_TAB_MODIFICATIONS.PARTITION_NAME IS 'Modified partition'
/
COMMENT ON COLUMN SYS.USER_TAB_MODIFICATIONS.SUBPARTITION_NAME IS 'Modified subpartition'
/
COMMENT ON COLUMN SYS.USER_TAB_MODIFICATIONS.INSERTS IS 'Approximate number of rows inserted since last analyze'
/
COMMENT ON COLUMN SYS.USER_TAB_MODIFICATIONS.UPDATES IS 'Approximate number of rows updated since last analyze'
/
COMMENT ON COLUMN SYS.USER_TAB_MODIFICATIONS.DELETES IS 'Approximate number of rows deleted since last analyze'
/
COMMENT ON COLUMN SYS.USER_TAB_MODIFICATIONS.TIMESTAMP IS 'Timestamp of last time this row was modified'
/
COMMENT ON COLUMN SYS.USER_TAB_MODIFICATIONS.TRUNCATED IS 'Was this object truncated since the last analyze?'
/
COMMENT ON COLUMN SYS.USER_TAB_MODIFICATIONS.DROP_SEGMENTS IS 'Number of (sub)partition segment dropped since the last analyze?'
/
