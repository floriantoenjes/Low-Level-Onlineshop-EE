CREATE VIEW USER_TAB_PARTITIONS AS select o.name, 'NO', o.subname, 0,
       tp.hiboundval, tp.hiboundlen,
       row_number() over (partition by o.name order by tp.part#),
       ts.name, tp.pctfree$,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tp.pctused$),
       tp.initrans, tp.maxtrans,
       decode(bitand(tp.flags, 65536), 65536,
              ds.initial_stg * ts.blocksize, s.iniexts * ts.blocksize),
       decode(bitand(tp.flags, 65536), 65536,
              ds.next_stg * ts.blocksize, s.extsize * ts.blocksize),
       decode(bitand(tp.flags, 65536), 65536, ds.minext_stg, s.minexts),
       decode(bitand(tp.flags, 65536), 65536, ds.maxext_stg, s.maxexts),
       decode(bitand(tp.flags, 65536), 65536,
              ds.maxsiz_stg * ts.blocksize,
              decode(bitand(s.spare1, 4194304), 4194304, bitmapranges, NULL)),
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
              decode(bitand(tp.flags, 65536), 65536, ds.pctinc_stg, s.extpct)),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
              decode(bitand(tp.flags, 65536), 65536,
                     decode(ds.frlins_stg, 0, 1, ds.frlins_stg),
                     decode(s.lists, 0, 1, s.lists))),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
              decode(bitand(tp.flags, 65536), 65536,
                     decode(ds.maxins_stg, 0, 1, ds.maxins_stg),
                     decode(s.groups, 0, 1, s.groups))),
       decode(mod(trunc(tp.flags / 4), 2), 0, 'YES', 'NO'),
       case when (bitand(tp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 4), 4, 'ENABLED', 'DISABLED')
       else
         decode(bitand(s.spare1, 2048), 2048, 'ENABLED', 'DISABLED')
       end,
       case when (bitand(tp.flags, 65536) = 65536) then
          decode(bitand(ds.flags_stg, 4), 4,
          case when bitand(ds.cmpflag_stg, 3) = 1 then 'BASIC'
               when bitand(ds.cmpflag_stg, 3) = 2 then 'OLTP'
               else decode(ds.cmplvl_stg, 1, 'QUERY LOW',
                                          2, 'QUERY HIGH',
                                          3, 'ARCHIVE LOW',
                                             'ARCHIVE HIGH') end,
           null)
       else
         decode(bitand(s.spare1, 2048), 0, null,
           case when bitand(s.spare1, 16777216) = 16777216
                     then 'OLTP'
                when bitand(s.spare1, 100663296) = 33554432  -- 0x2000000
                     then 'QUERY LOW'
                when bitand(s.spare1, 100663296) = 67108864  -- 0x4000000
                     then 'QUERY HIGH'
                when bitand(s.spare1, 100663296) = 100663296 -- 0x2000000+0x4000000
                     then 'ARCHIVE LOW'
                when bitand(s.spare1, 134217728) = 134217728 -- 0x8000000
                     then 'ARCHIVE HIGH'
                else 'BASIC' end)
       end,
       tp.rowcnt, tp.blkcnt, tp.empcnt, tp.avgspc, tp.chncnt, tp.avgrln,
       tp.samplesize, tp.analyzetime,
       decode(bitand(decode(bitand(tp.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 3),
              1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(bitand(decode(bitand(tp.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 12)/4,
              1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(decode(bitand(tp.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 48)/16,
              1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(tp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tp.flags, 8), 0, 'NO', 'YES'),
       decode(bitand(o.flags, 16384), 0, 'NO', 'YES'),
       case bitand(o.flags, 16384)   --is the object a nested table partition?
       when  16384 then
       (select o1.subname
        from obj$ o1
        where o1.obj#=
        (select tp1.obj#
         from tabpartv$ tp1, tabpartv$ tp2, ntab$ nt
         where tp2.bo# = tp.bo#
         and tp2.obj# = tp.obj#
         and tp1.part# = tp2.part#
         and tp1.bo#=nt.obj#
         and nt.ntab#=tp.bo#))
       else
         null
       end,
       decode(bitand(tp.flags, 32768), 32768, 'YES', 'NO'),
       decode(bitand(tp.flags, 65536), 65536, 'NO', 'YES')
from   obj$ o, tabpart$ tp, ts$ ts, sys.seg$ s, sys.tab$ t,
       sys.deferred_stg$ ds
where  o.obj# = tp.obj# and ts.ts# = tp.ts# and tp.obj# = ds.obj#(+) and
       tp.file#=s.file#(+) and tp.block#=s.block#(+) and tp.ts#=s.ts#(+) and
       bitand(t.property, 64) != 64 and
       tp.bo# = t.obj# and bitand(t.trigflag, 1073741824) != 1073741824 and
       o.owner# = userenv('SCHEMAID')
       and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
union all -- IOT PARTITIONS
select o.name, 'NO', o.subname, 0,
       tp.hiboundval, tp.hiboundlen,
       row_number() over (partition by o.name order by tp.part#), NULL,
       TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),
       TO_NUMBER(NULL), TO_NUMBER(NULL),
       TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),
       TO_NUMBER(NULL),TO_NUMBER(NULL),
       NULL,
       'N/A', 'N/A',
       tp.rowcnt, TO_NUMBER(NULL), TO_NUMBER(NULL), 0, tp.chncnt, tp.avgrln,
       tp.samplesize, tp.analyzetime, NULL, NULL, NULL,
       decode(bitand(tp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tp.flags, 8), 0, 'NO', 'YES'),
       'N/A', 'N/A', 'N/A',
       decode(bitand(tp.flags, 65536), 65536, 'NO', 'YES')
from   obj$ o, tabpart$ tp, tab$ t
where  o.obj# = tp.obj# and
       tp.bo# = t.obj# and bitand(t.trigflag, 1073741824) != 1073741824 and
       bitand(t.property, 64) = 64 and
       o.owner# = userenv('SCHEMAID')
       and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
union all -- COMPOSITE PARTITIONS
select o.name, 'YES', o.subname, tcp.subpartcnt,
       tcp.hiboundval, tcp.hiboundlen,
       row_number() over (partition by o.name order by tcp.part#),
       ts.name, tcp.defpctfree,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tcp.defpctused),
       tcp.definitrans, tcp.defmaxtrans,
       tcp.definiexts, tcp.defextsize, tcp.defminexts, tcp.defmaxexts,
       tcp.defmaxsize, tcp.defextpct,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tcp.deflists),
       decode(bitand(ts.flags, 32), 32,  to_number(NULL),tcp.defgroups),
       decode(tcp.deflogging, 0, 'NONE', 1, 'YES', 2, 'NO', 'UNKNOWN'),
       decode(bitand(tcp.spare2, 3), 1, 'ENABLED', 2, 'DISABLED', 'NONE'),
       decode(bitand(tcp.spare2, 1), 0, null,
         case bitand(tcp.spare2, 63) -- 1st 6 bits used
         when 1 then 'BASIC'                               -- 00000001
         when 5 then 'OLTP'                                -- 00000101
         when 9 then 'QUERY LOW'                           -- 00001001
         when 17 then 'QUERY HIGH'                         -- 00010001
         when 25 then 'ARCHIVE LOW'                        -- 00011001
         when 33 then 'ARCHIVE HIGH'                       -- 00100001
                 else 'UNKNOWN' end),                      -- internal ilevels
       tcp.rowcnt, tcp.blkcnt, tcp.empcnt, tcp.avgspc, tcp.chncnt, tcp.avgrln,
       tcp.samplesize, tcp.analyzetime,
       decode(bitand(tcp.defbufpool, 3), 1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(bitand(tcp.defbufpool, 12)/4, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(tcp.defbufpool, 48)/16, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(tcp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tcp.flags, 8), 0, 'NO', 'YES'),
       'N/A', 'N/A',
       decode(bitand(tcp.flags, 32768), 32768, 'YES', 'NO'),
       decode(bitand(tcp.spare2, 768), 256, 'NO', 512, 'YES', 'NONE')
from   obj$ o, tabcompart$ tcp, ts$ ts, tab$ t
where  o.obj# = tcp.obj# and tcp.defts# = ts.ts# and
       o.owner# = userenv('SCHEMAID') and
       bitand(t.property, 64) != 64 and
       o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL and
       tcp.bo# = t.obj#
       and bitand(t.trigflag, 1073741824) != 1073741824
/
