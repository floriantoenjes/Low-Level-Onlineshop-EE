CREATE VIEW USER_TAB_PRIVS_MADE AS select ue.name, o.name, ur.name, tpm.name,
       decode(mod(oa.option$,2), 1, 'YES', 'NO'),
       decode(bitand(oa.option$,2), 2, 'YES', 'NO')
from sys.objauth$ oa, sys."_CURRENT_EDITION_OBJ" o, sys.user$ ue, sys.user$ ur,
     table_privilege_map tpm
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and oa.col# is null
  and oa.privilege# = tpm.privilege
  and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_TAB_PRIVS_MADE IS 'All grants on objects owned by the user'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS_MADE.GRANTEE IS 'Name of the user to whom access was granted'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS_MADE.TABLE_NAME IS 'Name of the object'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS_MADE.GRANTOR IS 'Name of the user who performed the grant'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS_MADE.PRIVILEGE IS 'Table Privilege'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS_MADE.GRANTABLE IS 'Privilege is grantable'
/
COMMENT ON COLUMN SYS.USER_TAB_PRIVS_MADE.HIERARCHY IS 'Privilege is with hierarchy option'
/
