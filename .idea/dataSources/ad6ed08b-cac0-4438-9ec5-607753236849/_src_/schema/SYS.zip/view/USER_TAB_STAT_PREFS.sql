CREATE VIEW USER_TAB_STAT_PREFS AS select o.name, p.pname, p.valchar
from  sys.optstat_user_prefs$ p, obj$ o
where p.obj#=o.obj#
  and o.type#=2
  and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_TAB_STAT_PREFS IS 'Statistics preferences for tables'
/
COMMENT ON COLUMN SYS.USER_TAB_STAT_PREFS.TABLE_NAME IS 'Name of the table'
/
COMMENT ON COLUMN SYS.USER_TAB_STAT_PREFS.PREFERENCE_NAME IS 'Preference name'
/
COMMENT ON COLUMN SYS.USER_TAB_STAT_PREFS.PREFERENCE_VALUE IS 'Preference value'
/
