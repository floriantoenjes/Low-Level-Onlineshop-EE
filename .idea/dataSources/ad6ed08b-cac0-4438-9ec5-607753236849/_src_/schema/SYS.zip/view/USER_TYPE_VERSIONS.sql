CREATE VIEW USER_TYPE_VERSIONS AS select o.name, t.version#,
       decode(t.typecode, 108, 'OBJECT',
                          122, 'COLLECTION',
                          o.name),
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID'),
       s.line, s.source,
       t.hashcode
from sys."_CURRENT_EDITION_OBJ" o, sys.source$ s, sys.type$ t
  where o.obj# = s.obj# and o.oid$ = t.tvoid and o.type# = 13
  and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_TYPE_VERSIONS IS 'Description of each version of the user''s types'
/
COMMENT ON COLUMN SYS.USER_TYPE_VERSIONS.TYPE_NAME IS 'Name of the type'
/
COMMENT ON COLUMN SYS.USER_TYPE_VERSIONS.VERSION# IS 'Internal version number of the type'
/
COMMENT ON COLUMN SYS.USER_TYPE_VERSIONS.TYPECODE IS 'Typecode of the type'
/
COMMENT ON COLUMN SYS.USER_TYPE_VERSIONS.STATUS IS 'Status of the type'
/
COMMENT ON COLUMN SYS.USER_TYPE_VERSIONS.LINE IS 'Line number of the type''s spec'
/
COMMENT ON COLUMN SYS.USER_TYPE_VERSIONS.TEXT IS 'Text of the type''s spec'
/
COMMENT ON COLUMN SYS.USER_TYPE_VERSIONS.HASHCODE IS 'Hashcode of the type'
/
