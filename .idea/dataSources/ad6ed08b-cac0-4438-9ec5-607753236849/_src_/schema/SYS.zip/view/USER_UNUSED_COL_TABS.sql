CREATE VIEW USER_UNUSED_COL_TABS AS select o.name, count(*)
from sys.col$ c, sys.obj$ o
where o.obj# = c.obj#
  and o.owner# = userenv('SCHEMAID')
  and bitand(c.property, 32768) = 32768             -- is unused columns
  and bitand(c.property, 1) != 1                    -- not ADT attribute col
  and bitand(c.property, 1024) != 1024              -- not NTAB's setid col
  group by o.name
/
COMMENT ON VIEW SYS.USER_UNUSED_COL_TABS IS 'User tables with unused columns'
/
COMMENT ON COLUMN SYS.USER_UNUSED_COL_TABS.TABLE_NAME IS 'Name of the table'
/
COMMENT ON COLUMN SYS.USER_UNUSED_COL_TABS.COUNT IS 'Number of unused columns in table'
/
