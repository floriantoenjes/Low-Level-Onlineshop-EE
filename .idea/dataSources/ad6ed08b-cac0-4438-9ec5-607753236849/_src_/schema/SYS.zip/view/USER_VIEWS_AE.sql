CREATE VIEW USER_VIEWS_AE AS select o.name, v.textlength, v.text, t.typetextlength, t.typetext,
       t.oidtextlength, t.oidtext, t.typeowner, t.typename,
       decode(bitand(v.property, 134217728), 134217728,
              (select sv.name from superobj$ h, obj$ sv
              where h.subobj# = o.obj# and h.superobj# = sv.obj#), null),
       decode(bitand(v.property, 32), 32, 'Y', 'N'),
       decode(bitand(v.property, 16384), 16384, 'Y', 'N'),
       o.defining_edition
from sys."_ACTUAL_EDITION_OBJ" o, sys.view$ v, sys.typed_view$ t
where o.obj# = v.obj#
  and o.obj# = t.obj#(+)
  and o.owner# = userenv('SCHEMAID')
/
COMMENT ON VIEW SYS.USER_VIEWS_AE IS 'Description of the user''s own views'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.VIEW_NAME IS 'Name of the view'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.TEXT_LENGTH IS 'Length of the view text'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.TEXT IS 'View text'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.TYPE_TEXT_LENGTH IS 'Length of the type clause of the object view'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.TYPE_TEXT IS 'Type clause of the object view'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.OID_TEXT_LENGTH IS 'Length of the WITH OBJECT OID clause of the object view'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.OID_TEXT IS 'WITH OBJECT OID clause of the object view'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.VIEW_TYPE_OWNER IS 'Owner of the type of the view if the view is a object view'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.VIEW_TYPE IS 'Type of the view if the view is a object view'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.SUPERVIEW_NAME IS 'Name of the superview, if view is a subview'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.EDITIONING_VIEW IS 'An indicator of whether the view is an Editioning View'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.READ_ONLY IS 'An indicator of whether the view is a Read Only View'
/
COMMENT ON COLUMN SYS.USER_VIEWS_AE.EDITION_NAME IS 'Name of the Application Edition where the object is defined'
/
