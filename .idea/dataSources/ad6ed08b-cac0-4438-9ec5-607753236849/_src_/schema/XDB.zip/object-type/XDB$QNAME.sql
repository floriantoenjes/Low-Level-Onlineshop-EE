CREATE type     xdb$qname                                       
as object
(
    prefix_code     raw(4), /* Index into schema extras */
    name            varchar2(2000)
);
/
