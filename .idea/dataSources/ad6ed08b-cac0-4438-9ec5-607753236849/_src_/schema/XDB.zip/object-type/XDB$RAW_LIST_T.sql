CREATE type     xdb$raw_list_t                                       
as varray(2147483647) of raw(2000);
/
