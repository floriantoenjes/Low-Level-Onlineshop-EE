CREATE type     xdb$string_list_t                                       
as VARRAY(2147483647) of varchar2(4000);
/
