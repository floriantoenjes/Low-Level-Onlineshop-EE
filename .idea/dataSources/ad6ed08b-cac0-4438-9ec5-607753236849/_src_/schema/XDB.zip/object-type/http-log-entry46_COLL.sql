CREATE TYPE       "http-log-entry46_COLL" AS VARRAY(2147483647) OF "http-log-entry-type42_T"
/
