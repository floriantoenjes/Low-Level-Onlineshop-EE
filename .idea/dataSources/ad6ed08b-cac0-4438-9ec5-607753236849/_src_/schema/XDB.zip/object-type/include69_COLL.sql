CREATE TYPE       "include69_COLL" AS VARRAY(2147483647) OF "includeType62_T"
/
